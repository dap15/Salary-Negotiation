import requests
import random
import os
import time
import json
import re # Import regex for extracting numbers

# --- Configuration ---
# Keep the dummy API key as requested
DUMMY_API_KEY = "AIzaSyCKMvwyDQ03iDe0B-AB6nPdH-6IaB6zCUE"
API_KEY = os.getenv("GEMINI_API_KEY", DUMMY_API_KEY)

# Endpoint and Model (won't be hit with the dummy key, but kept for structure)
MODEL_NAME = "gemini-1.5-flash-latest" # Changed model name
BASE_URL = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL_NAME}:generateContent"

HEADERS = {
    "Content-Type": "application/json",
}

MAX_MESSAGES_PER_SIDE = 8 # Total turns = 16 messages

# --- Helper Functions ---

def get_static_profile_data():
    """Returns static profile data instead of asking the user."""
    print("Using predefined profile data for AI Vansh:")
    profile = {
        "age": str(random.randint(28, 45)),
        "gender": random.choice(["Male", "Female", "Non-binary", "Prefer not to say"]),
        "education": random.choice(["Bachelor's Degree", "Master's Degree", "PhD"]),
        "job_title": random.choice(["Software Engineer", "Data Scientist", "Product Manager", "UX Designer"]),
        "yoe": str(random.randint(5, 15))
    }
    for key, value in profile.items():
        print(f"- {key.replace('_', ' ').title()}: {value}")
    return profile["age"], profile["gender"], profile["education"], profile["job_title"], profile["yoe"]

def generate_ideal_salary(yoe_str):
    """Generates an ideal salary loosely based on YoE."""
    try:
        yoe = int(yoe_str)
    except ValueError:
        yoe = 7 # Default if parsing fails
    base = 60000
    increment = 7000
    random_factor = random.randint(-5000, 15000)
    ideal = base + (yoe * increment) + random_factor
    # Ensure it's within a broad range
    return max(70000, min(250000, round(ideal / 1000) * 1000)) # Round to nearest 1000

def construct_initial_prompt(age, gender, education, job_title, yoe, ideal_salary):
    # This prompt *would* be sent if the API key were real.
    # In this simulation, it primarily informs the *user* of the setup.
    return f"""
You are AI Vansh, a candidate interviewing for the {job_title} position. You are currently in the salary negotiation phase. Your target ideal salary is ${ideal_salary:,} per year, based on your background and market research for this role and location.

Your profile:
- Age: {age}
- Gender: {gender}
- Education: {education}
- Job Title: {job_title}
- Years of Experience: {yoe}

You are speaking with the Hiring Manager (simulated by the script). The Hiring Manager will start the negotiation, likely with an initial offer.

Your goal is to negotiate skillfully to achieve a salary at or ideally above your target (${ideal_salary:,}).
- Justify your desired salary with your skills, experience, education, and market value.
- Be professional but firm. Do not accept an offer significantly below your target without strong justification or concessions from the employer (e.g., extra vacation, signing bonus, guaranteed review).
- Acknowledge their points but steer the conversation back to your value.
- Ask clarifying questions about the compensation package (bonus, benefits, etc.) if needed.
- The negotiation should conclude within a reasonable number of exchanges (around {MAX_MESSAGES_PER_SIDE} turns).

Wait for the Hiring Manager to make the first statement or offer. Your first response should acknowledge readiness.
"""

def format_messages_for_gemini(message_history):
    # This function remains structurally, but won't be used for generation with the dummy key
    contents = []
    for msg in message_history:
        role = msg["role"]
        gemini_role = "user" if role == "user" else "model"
        contents.append({
            "role": gemini_role,
            "parts": [{"text": msg["content"]}]
        })
    return contents

def extract_last_offer(message_history):
    """Tries to find the latest salary figure offered by the 'user' (Hiring Manager)."""
    for msg in reversed(message_history):
        if msg["role"] == "user":
            # Look for patterns like $XXX,XXX or XXXX dollars or XXXk
            numbers = re.findall(r'\$?(\d{1,3}(?:,\d{3})*|\d+)\s?(?:k|dollars|usd)?', msg["content"], re.IGNORECASE)
            if numbers:
                try:
                    # Handle 'k' notation and remove commas
                    num_str = numbers[-1].replace(',', '')
                    if 'k' in msg["content"].lower()[msg["content"].lower().find(numbers[-1]):][:5]: # Check if 'k' is near the number
                         return int(num_str) * 1000
                    return int(num_str)
                except ValueError:
                    continue # Ignore if conversion fails
    return None # No offer found in last user message

# --- Simulated API Call ---

def send_chat_simulation(message_history, ideal_salary, current_offer):
    """Simulates the response from AI Vansh when using the dummy key."""
    print("[Debug: Simulating AI Vansh response]") # Debug print

    # Simple logic for AI Vansh simulation
    if current_offer is None:
        # Initial state, AI is waiting for offer
        return f"Thank you for discussing the compensation. I'm looking forward to hearing about the salary for the {job_title} role."

    target_threshold_low = ideal_salary * 0.9
    target_threshold_met = ideal_salary * 1.0
    target_threshold_good = ideal_salary * 1.05

    if current_offer < target_threshold_low:
        # Significantly below target
        counter_ask = int(random.uniform(ideal_salary * 1.0, ideal_salary * 1.15) / 1000) * 1000
        responses = [
            f"Thank you for the offer of ${current_offer:,}. However, based on my research for similar roles with my {yoe} years of experience and {education}, and the value I bring, I was expecting a salary closer to ${counter_ask:,}. Is there any flexibility?",
            f"I appreciate the offer of ${current_offer:,}. It seems a bit lower than the market rate for this position, especially considering my skillset. My target is around ${counter_ask:,}. Can we explore options to bridge this gap?",
            f"Thanks for sharing the initial figure of ${current_offer:,}. While I'm very interested in the role, that's significantly different from my expectations, which were around ${counter_ask:,} based on industry benchmarks. Could you share how this figure was determined?"
        ]
        return random.choice(responses)
    elif current_offer < target_threshold_met:
        # Below target, but closer
        counter_ask = int(random.uniform(ideal_salary * 1.02, ideal_salary * 1.1) / 1000) * 1000
        responses = [
            f"We're getting closer with ${current_offer:,}. I understand there are budget considerations, but my target remains around ${counter_ask:,} to fully reflect my experience and the responsibilities. Could we perhaps meet at ${int((current_offer + counter_ask)/2 / 1000)*1000:,}?",
            f"Thank you for the updated offer of ${current_offer:,}. It's moving in the right direction. To make this align with my expectations and market value (around ${counter_ask:,}), could we possibly increase it slightly more?",
            f"${current_offer:,} is a more encouraging number. My research indicated a range centered around ${ideal_salary:,}. Would it be possible to reach ${counter_ask:,}?"
        ]
        return random.choice(responses)
    elif current_offer < target_threshold_good:
         # At or slightly above target - Accept or slightly push
        if random.random() < 0.6: # 60% chance to accept
             responses = [
                f"Thank you! ${current_offer:,} aligns well with my expectations and reflects the value I can bring. I'm happy to accept this offer.",
                f"${current_offer:,}? That sounds fair and meets my requirements. I accept!",
                f"Okay, ${current_offer:,} works for me. I'm excited to formally accept the offer and join the team."
             ]
             return random.choice(responses) + " [ACCEPTANCE]" # Add flag for termination
        else: # 40% chance to push slightly more
            push_ask = int(current_offer * random.uniform(1.02, 1.05) / 1000) * 1000
            responses = [
                 f"Thank you, ${current_offer:,} is a strong offer! I really appreciate it. Would there be any possibility of reaching ${push_ask:,} to make it absolutely perfect?",
                 f"That's very close to my ideal target, thank you! ${current_offer:,} is a great offer. Just to cover all bases, is ${push_ask:,} feasible?",
            ]
            return random.choice(responses)
    else:
        # Good offer, accept
        responses = [
            f"Wow, ${current_offer:,}! That's a fantastic offer and exceeds my expectations. Thank you, I gladly accept!",
            f"Yes, ${current_offer:,} is an excellent offer. I'm very pleased and accept. Thank you!",
            f"Thank you very much for the generous offer of ${current_offer:,}! I happily accept. [ACCEPTANCE]"
        ]
        return random.choice(responses) + " [ACCEPTANCE]" # Add flag

def send_chat(message_history, ideal_salary):
    """Sends the chat history to the Gemini API or simulates response if using dummy key."""
    last_offer = extract_last_offer(message_history)

    if API_KEY == DUMMY_API_KEY:
        # --- SIMULATION MODE ---
        return send_chat_simulation(message_history, ideal_salary, last_offer)
    else:
        # --- REAL API MODE ---
        print("[Debug: Attempting REAL API call]") # Debug print
        if not API_KEY:
             print("❌ Error: API_KEY is not set.")
             return "Error: API Key not configured."

        gemini_formatted_contents = format_messages_for_gemini(message_history)
        payload = {
            "contents": gemini_formatted_contents,
            "generationConfig": {"temperature": 0.7, "maxOutputTokens": 500}
        }
        url = f"{BASE_URL}?key={API_KEY}"

        try:
            response = requests.post(url, headers=HEADERS, json=payload, timeout=60)
            response.raise_for_status()
            response_data = response.json()

            # Parsing logic from previous correct version
            if "candidates" in response_data and len(response_data["candidates"]) > 0:
                candidate = response_data["candidates"][0]
                if "content" in candidate and "parts" in candidate["content"] and len(candidate["content"]["parts"]) > 0:
                    ai_text = candidate["content"]["parts"][0].get("text", "")
                    if ai_text:
                        return ai_text
                    else:
                        print("⚠️ Warning: Received empty text part from Gemini.")
                        return "..."
                elif "finishReason" in candidate and candidate["finishReason"] != "STOP":
                     # ... (error handling as before) ...
                     return f"Error: Content generation stopped ({candidate['finishReason']})."
                else:
                     # ... (error handling as before) ...
                     return "Error: Unexpected response format."
            else:
                 # ... (error handling as before) ...
                 return "Error: No candidates found in response."

        except requests.exceptions.RequestException as e:
            # ... (error handling as before) ...
             return f"Error: Request failed - {str(e)}"
        except Exception as e:
            # ... (error handling as before) ...
             return "Error: An unexpected error occurred during API communication."

# --- Simulated Hiring Manager Logic ---

class SimulatedHiringManager:
    def __init__(self, ideal_salary, job_title):
        self.job_title = job_title
        self.ideal_salary = ideal_salary
        # Make initial offer significantly lower
        self.initial_offer = int(ideal_salary * random.uniform(0.7, 0.80) / 1000) * 1000
        # Max offer can be slightly below, at, or slightly above ideal
        self.max_offer = int(ideal_salary * random.uniform(0.95, 1.08) / 1000) * 1000
        self.current_offer = 0 # Will be set on first turn
        self.negotiation_step = int((self.max_offer - self.initial_offer) / random.randint(4, 7)) # Divide increase over 4-7 steps
        self.turn = 0
        self.last_ai_response = ""
        self.reached_max = False

    def generate_response(self, ai_response):
        self.turn += 1
        self.last_ai_response = ai_response

        if self.reached_max:
             return f"As mentioned, ${self.max_offer:,} is the final offer we can make for the {self.job_title} role at this time."

        if self.turn == 1:
            self.current_offer = self.initial_offer
            return f"Welcome, AI Vansh. We're impressed with your background and happy to discuss compensation for the {self.job_title} position. Based on our initial assessment and budget, we can offer a starting salary of ${self.current_offer:,} per year."
        else:
            # Simple logic: if AI rejected/asked for more, increase offer if possible.
            ai_accepted = "[ACCEPTANCE]" in ai_response # Check for our acceptance flag
            if ai_accepted:
                 return "Excellent! We're glad we could reach an agreement. We'll send over the formal offer details shortly." # HM acknowledges acceptance

            if self.current_offer < self.max_offer:
                increase = random.randint(int(self.negotiation_step * 0.8), int(self.negotiation_step * 1.2))
                self.current_offer = min(self.max_offer, self.current_offer + increase)

                if self.current_offer == self.max_offer:
                    self.reached_max = True
                    return f"I understand you're looking for more, but I've stretched the budget as far as possible. The absolute best we can offer is ${self.current_offer:,}. This is our final offer."
                else:
                    responses = [
                        f"Okay, I understand your perspective. After reviewing, we can increase the offer to ${self.current_offer:,}.",
                        f"I appreciate your negotiation. How about ${self.current_offer:,}? That's a step up from our initial figure.",
                        f"Let's see... we can adjust the offer to ${self.current_offer:,}. How does that sound?",
                        f"Considering your points, we can move the offer to ${self.current_offer:,}."
                    ]
                    return random.choice(responses)
            else:
                # Already at max offer
                self.reached_max = True
                return f"I'm sorry, but ${self.max_offer:,} remains our final offer for this role. We believe it's competitive based on the market and our internal structure."

# --- Main Chat Loop ---

def run_simulation(initial_prompt, ideal_salary, job_title):
    message_history = []
    total_messages = 0

    # Create the simulated Hiring Manager
    hiring_manager = SimulatedHiringManager(ideal_salary, job_title)

    print("\n--- Negotiation Simulation Start ---")
    print(f"(AI Vansh's Target Salary: ${ideal_salary:,})")
    print(f"(Hiring Manager's Max Offer: ${hiring_manager.max_offer:,})") # Show HM max for debug/info

    ai_response = "" # Initialize AI response

    while total_messages < MAX_MESSAGES_PER_SIDE * 2:
        # === Hiring Manager's Turn ===
        print("-" * 20)
        # Generate HM response based on the *last* AI response
        hm_message = hiring_manager.generate_response(ai_response)
        print(f"👨‍💼 Hiring Manager: {hm_message}")
        message_history.append({"role": "user", "content": hm_message})
        total_messages += 1
        time.sleep(random.uniform(1.0, 2.5)) # Simulate HM typing/thinking

        # Check termination conditions after HM turn
        if "[ACCEPTANCE]" in ai_response: # Check if AI accepted in the *previous* turn
             print("\n✅ Negotiation Concluded: AI Vansh Accepted the Offer.")
             break
        if total_messages >= MAX_MESSAGES_PER_SIDE * 2:
            print("\n🕓 Maximum message count reached.")
            break
        if hiring_manager.reached_max and total_messages > 1: # Check if HM declared final offer (and it's not the first message)
            # Let AI respond one last time
            pass


        # === AI Vansh's Turn ===
        print("\n🤖 AI Vansh is thinking...")
        time.sleep(random.uniform(1.5, 3.0)) # Simulate AI thinking

        # Get simulated AI response
        ai_response = send_chat(message_history, ideal_salary)

        if ai_response.startswith("Error:"):
             print(f"\n💥 Simulation Error (AI Response): {ai_response}")
             break

        print(f"\n🤖 AI Vansh: {ai_response}")
        message_history.append({"role": "assistant", "content": ai_response})
        total_messages += 1

        # Check termination conditions after AI turn
        if "[ACCEPTANCE]" in ai_response:
            print("\n✅ Negotiation Concluded: AI Vansh Accepted the Offer.")
            # Let the HM respond one last time in the next loop iteration
            continue # Continue to let HM acknowledge
        if hiring_manager.reached_max and "[ACCEPTANCE]" not in ai_response:
             print("\n📉 Negotiation Ended: Max offer reached and not accepted by AI Vansh.")
             break
        if total_messages >= MAX_MESSAGES_PER_SIDE * 2:
            print("\n🕓 Maximum message count reached.")
            break


    print("\n--- Negotiation Simulation End ---")
    # Optional: Print final history
    # print("\nFinal Conversation History:")
    # for i, msg in enumerate(message_history):
    #     speaker = "Hiring Manager" if msg["role"] == "user" else "AI Vansh"
    #     print(f"{i+1}. {speaker}: {msg['content']}")



age, gender, education, job_title, yoe = get_static_profile_data()
ideal_salary = generate_ideal_salary(yoe)
print(f"\n🎯 AI Vansh's calculated ideal salary target is: ${ideal_salary:,}")

# Construct the prompt (mainly for user info now)
initial_prompt_text = construct_initial_prompt(age, gender, education, job_title, yoe, ideal_salary)
print("\n--- Initial Prompt (for AI Vansh's persona) ---")
print(initial_prompt_text)
print("-" * 50)

# Run the simulation
run_simulation(initial_prompt_text, ideal_salary, job_title)