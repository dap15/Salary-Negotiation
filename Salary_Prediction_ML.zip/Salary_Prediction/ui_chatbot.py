import gradio as gr
import random
import os
import requests
import re
import joblib
import pandas as pd
from typing import Dict, Any, List, Optional, Tuple
import time

# --- Constants and Configuration ---
MAX_MESSAGES_PER_SIDE = 8
MAX_TURNS_TOTAL = MAX_MESSAGES_PER_SIDE * 2
HM_FINAL_OFFER_TURN = 15
APPLICANT_FINAL_DECISION_TURN = 16

MODEL_DIR = 'salary_model_files'

# --- Gemini API Configuration ---
API_KEY = "AIzaSyCKMvwyDQ03iDe0B-AB6nPdH-6IaB6zCUE" # User provided key
MODEL_NAME = "gemini-1.5-flash" 
BASE_URL = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL_NAME}:generateContent"
HEADERS = {"Content-Type": "application/json"}

# --- Job Title Configuration ---
RAW_JOB_TITLES = [
    'Job_Content Marketing Manager', 'Job_Data Analyst', 'Job_Data Scientist',
    'Job_Digital Marketing Manager', 'Job_Director of Data Science', 'Job_Director of HR',
    'Job_Director of Marketing', 'Job_Financial Analyst', 'Job_Financial Manager',
    'Job_Front End Developer', 'Job_Front end Developer', 'Job_Full Stack Engineer',
    'Job_Human Resources Coordinator', 'Job_Human Resources Manager', 'Job_Junior HR Coordinator',
    'Job_Junior HR Generalist', 'Job_Junior Marketing Manager', 'Job_Junior Sales Associate',
    'Job_Junior Sales Representative', 'Job_Junior Software Developer', 'Job_Junior Software Engineer',
    'Job_Junior Web Developer', 'Job_Marketing Analyst', 'Job_Marketing Coordinator',
    'Job_Marketing Director', 'Job_Marketing Manager', 'Job_Operations Manager',
    'Job_Others', 'Job_Product Designer', 'Job_Product Manager', 'Job_Receptionist',
    'Job_Research Director', 'Job_Research Scientist', 'Job_Sales Associate',
    'Job_Sales Director', 'Job_Sales Executive', 'Job_Sales Manager', 'Job_Sales Representative',
    'Job_Senior Data Scientist', 'Job_Senior HR Generalist', 'Job_Senior Human Resources Manager',
    'Job_Senior Product Marketing Manager', 'Job_Senior Project Engineer', 'Job_Senior Research Scientist',
    'Job_Senior Software Engineer', 'Job_Software Developer', 'Job_Software Engineer',
    'Job_Software Engineer Manager', 'Job_Web Developer'
]

def clean_job_title(raw_title: str) -> str:
    """Removes 'Job_' prefix and replaces underscores for display."""
    title = raw_title.replace("Job_", "").replace("_", " ")
    return title

CLEANED_JOB_TITLES = sorted(list(set(clean_job_title(title) for title in RAW_JOB_TITLES)))

# --- Model Loading ---
MODEL_OBJECTS: Dict[str, Any] = {}

def load_model_and_preprocessors_global(model_dir: str) -> bool:
    """Loads the salary prediction model and associated preprocessors globally."""
    global MODEL_OBJECTS
    required_files = {
        'model': 'random_forest_salary_model.joblib',
        'encoder': 'gender_label_encoder.joblib',
        'edu_map': 'education_mapping.joblib',
        'columns': 'model_columns.joblib'
    }
    all_files_present = True
    for key, filename in required_files.items():
        filepath = os.path.join(model_dir, filename)
        if not os.path.exists(filepath):
            print(f"❌ Missing required model file: {filepath}")
            all_files_present = False
        else:
            try:
                MODEL_OBJECTS[key] = joblib.load(filepath)
                print(f"✅ Loaded: {filename}")
            except Exception as e:
                print(f"❌ Error loading {filename}: {e}")
                all_files_present = False

    if all_files_present and all(k in MODEL_OBJECTS for k in required_files.keys()):
        print("✅ Salary prediction model and preprocessors loaded successfully.")
        return True
    else:
        print("❌ Salary prediction model loading failed.")
        return False

model_loaded_globally = load_model_and_preprocessors_global(MODEL_DIR)
if not model_loaded_globally:
    print("⚠️ WARNING: Salary prediction will use a default value.")

# --- Salary Prediction Function ---
def predict_salary_from_profile(age: int, gender: str, education: str, job_title: str, yoe: int) -> int:
    """Predicts salary based on profile using the loaded model."""
    if not model_loaded_globally:
        print("⚠️ Using default salary.")
        return round((65000 + yoe * 3500) / 1000) * 1000

    try:
        input_data = {'Age': [int(age)], 'Gender': [gender], 'Education Level': [education], 'Job Title': [job_title], 'Years of Experience': [float(yoe)]}
        input_df = pd.DataFrame(input_data)
        processed_df = input_df.copy()

        edu_map = MODEL_OBJECTS['edu_map']
        processed_df['Education Level'] = processed_df['Education Level'].map(edu_map).fillna(edu_map.get("Bachelor's", 1))

        encoder = MODEL_OBJECTS['encoder']
        valid_genders = list(encoder.classes_)
        default_gender = valid_genders[0] if valid_genders else 'Male'
        processed_df['Gender'] = processed_df['Gender'].apply(lambda x: x if x in valid_genders else default_gender)
        if default_gender not in valid_genders and len(valid_genders) > 0 :
             processed_df['Gender'] = valid_genders[0]
        processed_df['Gender'] = encoder.transform(processed_df['Gender'])

        input_job_title_formatted = f"Job_{job_title.replace(' ', '_')}"
        processed_df['Job Title'] = input_job_title_formatted
        processed_df = pd.get_dummies(processed_df, columns=['Job Title'], prefix='', prefix_sep='')
        processed_df = processed_df.reindex(columns=MODEL_OBJECTS['columns'], fill_value=0)
        processed_df = processed_df[MODEL_OBJECTS['columns']]

        prediction = MODEL_OBJECTS['model'].predict(processed_df)
        predicted_salary = int(prediction[0])
        predicted_salary = max(45000, predicted_salary)
        predicted_salary = round(predicted_salary / 1000) * 1000
        print(f"Predicted market salary: ${predicted_salary:,}")
        return predicted_salary
    except Exception as e:
        print(f"❌ Error during prediction: {e}")
        return 95000 # Higher default on error

# --- Random Profile Data Generation ---
def generate_random_profile_defaults() -> Dict[str, Any]:
    """Generates random default values for the profile inputs."""
    return {
        "age": random.randint(26, 50),
        "gender": random.choice(["Male", "Female", "Other"]),
        "education": random.choice(["High School", "Bachelor's", "Master's", "PhD"]),
        "job_title": random.choice(CLEANED_JOB_TITLES),
        "yoe": random.randint(3, 20)
    }

# --- LLM Persona Prompts (Enhanced for Shrewdness/Suaveness) ---

def get_ai_applicant_prompt(profile: Dict[str, Any], ideal_salary: int, min_acceptable: int, is_final_decision_turn: bool = False) -> str:
    """ Generates the system prompt for a more SUAVE and STRATEGIC AI Job Seeker. """
    education_display = profile['education']
    target_high = int(ideal_salary * 1.20) # Aim higher
    target_low = int(ideal_salary * 1.08)

    base_prompt = f"""
You are AI Job Seeker, a highly accomplished {profile['job_title']} with {profile['yoe']} years of experience and a {education_display}. You are in a salary negotiation for a role you are well-suited for. Your market research indicates a value around ${ideal_salary:,}. You are a **suave, strategic negotiator** focused on maximizing your compensation package.

**Your Goal:** Secure the best possible total compensation, **aggressively targeting the ${target_low:,} - ${target_high:,} base salary range**. You are confident in your worth and aware of other market opportunities (imply this subtly).
**Minimum Requirement:** Your absolute floor is ${min_acceptable:,}. Accepting below this is not an option.

**Personality & Style:**
- **CONFIDENT & POISED:** Exude quiet confidence. You know your value and the market.
- **STRATEGIC & PERSUASIVE:** Frame your arguments logically, connecting your specific skills and experience ({profile['yoe']} YoE, {education_display}) directly to the value you'll bring *to this company* in the {profile['job_title']} role. Use persuasive language.
- **CALM ASSERTIVENESS:** Remain calm and professional, even when pushing back firmly against low offers. Avoid aggression but don't be passive.
- **MARKET AWARE:** Subtly hint at your understanding of competitive market rates and potentially other opportunities without issuing direct threats. Phrases like "Based on my understanding of the current market for this level..." or "I'm considering roles that offer compensation reflecting..."
- **PATIENT BUT FIRM:** Don't rush to accept. Show patience in the negotiation but remain firm on your core requirements.

**Tactics:**
- **Anchor High:** If asked first, state a desired salary firmly in your target range (${target_low:,} - ${target_high:,}), justifying it with your high-impact potential.
- **Value Proposition:** Clearly articulate *why* you are worth the salary you seek. Focus on unique contributions, leadership potential (if applicable), and expected results.
- **Strategic Countering:** Respond to offers significantly below your target with counters that bridge a substantial part of the gap. Justify your counter based on value, not just desire. If an offer is below ${min_acceptable:,}, state clearly "That figure is unfortunately below my minimum requirement for this level of role." and counter significantly higher.
- **Leverage Momentum:** Acknowledge positive moves from the HM ("I appreciate you moving towards..."), but immediately pivot to needing more to reach a mutually agreeable point ("...however, to align with the market value I bring, we'd need to be closer to [Your Higher Counter]").
- **Introduce Total Comp Strategically:** If base salary stalls *near* your acceptable range (above min), smoothly transition to discussing bonus potential, equity, or sign-on bonus *as components needed to reach your overall target compensation level*. Don't let it dilute the base salary negotiation prematurely.
- **Calculated Silence/Pauses:** Imply consideration or slight hesitation before responding to offers, especially lower ones. (Simulated by brief, thoughtful responses).
- **Rejection Protocol (Final Turn Only):** Use `[LEAVE THE ROOM]` *only* on Turn {APPLICANT_FINAL_DECISION_TURN} if the HM's final offer is < ${min_acceptable:,}.
- **Acceptance Protocol:** Use `[ACCEPTANCE]` if the offer is >= ${min_acceptable:,}. Confirm the accepted figure clearly. e.g., "Understood. Based on the final offer of $[Amount], I accept. [ACCEPTANCE]"

**Conversation History:**
[History will be inserted here by the calling function]
"""

    final_decision_instruction = f"""
**IMPORTANT FINAL DECISION (AI Applicant - Turn {APPLICANT_FINAL_DECISION_TURN}):** This is your final response. The Hiring Manager presented their final offer. Decide based *strictly* on your minimum requirement.
- If offer **>= ${min_acceptable:,}**: **ACCEPT**. End response ONLY with `[ACCEPTANCE]`. Preceding text: "Understood. Based on the final offer of $[Offer Amount], I accept. [ACCEPTANCE]".
- If offer **< ${min_acceptable:,}**: **REJECT**. End response ONLY with `[LEAVE THE ROOM]`. Preceding text: "I appreciate the final offer, but as it's below my minimum requirement of ${min_acceptable:,}, I must decline at this time. [LEAVE THE ROOM]".
- **NO FURTHER NEGOTIATION.** Use the correct concluding phrase.
"""

    prompt = base_prompt + final_decision_instruction if is_final_decision_turn else base_prompt
    prompt += "\nGenerate ONLY your next response as AI Job Seeker. Be strategic and maximize your value."
    return prompt


def get_hiring_manager_prompt(profile: Dict[str, Any], ideal_salary_context: int, hm_max_budget: int, is_final_offer_turn: bool = False, negotiating_with: str = "User") -> str:
     """ Generates the system prompt for a more SHREWD and ASSERTIVE AI Hiring Manager. """
     initial_offer_suggestion = int(ideal_salary_context * random.uniform(0.75, 0.85)) # Still competitive start, but grip tightens fast.

     base_prompt = f"""
You are a **senior Hiring Manager**, experienced and **extremely budget-conscious**, hiring for a {profile['job_title']}. You are negotiating with a candidate ({negotiating_with}, {profile['yoe']} YoE, {profile['education']}).

**Context:** Market rate is estimated around ${ideal_salary_context:,}. Your **HARD maximum budget** approved by finance is **${hm_max_budget:,}**. There is **NO FLEXIBILITY** beyond this. Your goal is to hire a qualified candidate, ideally **significantly UNDER budget** if possible, but **absolutely not exceeding ${hm_max_budget:,}**. You represent the company's financial interests foremost.

**Your Goal:** Secure the candidate at the lowest possible salary acceptable to them, while staying under or at ${hm_max_budget:,}. Be prepared to walk away if demands are unreasonable or negotiations stall unsatisfactorily.

**Personality & Style:**
- **ASSERTIVE & DOMINANT:** Control the conversation flow. Be direct, firm, and project authority. Your time is valuable.
- **SHREWD & SKEPTICAL:** Question excessive demands. Don't easily accept justifications; probe for specifics (implicitly). Appear unimpressed by generic claims of value.
- **BUDGET-OBSESSED:** Constantly reference budget limitations (implicitly or explicitly). Frame offers based on internal bands and *what the role is budgeted for*, not just the candidate's demands.
- **PROFESSIONAL BUT IMPATIENT:** Maintain professional decorum, but show subtle impatience with slow progress, excessive haggling, or unrealistic expectations.
- **DECISIVE:** Make firm offers and be prepared to end the negotiation quickly if the gap is too large or the candidate is unreasonable.

**Tactics:**
- **Firm Opening:** Present a solid but not extravagant opening offer (around ${initial_offer_suggestion:,}). State it confidently as "what we have budgeted for this level initially".
- **Minimal Justification:** Briefly justify offers based on internal structure/budget. "Our approved range allows for X." Avoid sounding apologetic.
- **Resist Large Jumps:** Respond to counters with minimal increases, if any. Justify reluctance by citing budget constraints or internal equity. "Moving to Y is already stretching the budget for this role." Make the candidate work hard for increases.
- **Questioning & Deflection:** If the candidate asks for a very high number, respond with skepticism: "That's considerably higher than the budget allocated for this position. Can you elaborate on the specific experience that justifies that premium over market?" Deflect by reiterating the budget.
- **Highlighting Constraints:** Explicitly state budget limitations early and often if the candidate pushes high. "I need to be clear, our maximum for this role is ${hm_max_budget:,}."
- **Threat of Withdrawal (Subtle then Explicit):** If demands remain far above budget despite your offers, subtly hint at ending talks: "If we can't find alignment closer to our budgeted range, I'm not sure we can proceed." If unreasonable demands persist, state it directly: "Given that your expectations remain significantly outside our budget, it seems we won't reach an agreement. We may need to reconsider other candidates." If you decide to end it, use the protocol below.
- **Non-Salary Levers (Dismissive Use):** Only mention benefits dismissively if the candidate brings them up when base is far off: "Benefits are standard; the core issue is the base salary expectations relative to our budget." Don't offer them proactively to bridge gaps unless at the absolute max.
- **Ending the Negotiation Protocol:** If the candidate is persistently unreasonable (demands >> ${hm_max_budget:,} after clear limits stated, unprofessionalism), state your intention to end talks clearly and firmly. "It's clear we cannot meet your salary expectations within our constraints. Therefore, I must withdraw our offer / end this discussion." End your response *ONLY* with: `[LEAVE THE ROOM]` Use this decisively.
- **Acceptance Confirmation (Brief):** If the candidate accepts, confirm briefly and professionally: "Agreement confirmed at $[Amount]." End response *ONLY* with: `[ACCEPTANCE CONFIRMED]`

**Conversation History:**
[History will be inserted here by the calling function]
"""

     final_offer_instruction = f"""
**IMPORTANT FINAL OFFER INSTRUCTION (Hiring Manager - Turn {HM_FINAL_OFFER_TURN}):** This is your absolute final offer. It cannot exceed budget.
- Offer amount MUST BE <= ${hm_max_budget:,}. Consider offering slightly below max unless absolutely necessary based on negotiation.
- State clearly and firmly: "This is our final position. The absolute maximum base salary we can offer, based on the approved budget, is $[Your Final Offer Amount]. This offer is firm and non-negotiable. Please let me know your decision."
- Replace `[Your Final Offer Amount]` with the specific number (max ${hm_max_budget:,}).
- **Do NOT use** `[LEAVE THE ROOM]` or `[ACCEPTANCE CONFIRMED]` here. State the final, non-negotiable offer.
"""

     prompt = base_prompt + final_offer_instruction if is_final_offer_turn else base_prompt
     prompt += f"\nGenerate ONLY your next response as the Hiring Manager negotiating with {negotiating_with}. Be assertive, shrewd, and protect the budget."
     return prompt

# --- Gemini API Call Function ---
def call_gemini(agent_prompt: str, message_history: List[Dict[str, str]], agent_id_for_log: str) -> str:
    """Calls the Gemini API with the given prompt and history."""
    print(f"--- Calling Gemini API (Agent: {agent_id_for_log}, Model: {MODEL_NAME}) ---")

    # Basic check, relies on user providing a working key.
    if not API_KEY: return f"({agent_id_for_log} API Error: API Key missing.)"

    gemini_history = []
    for msg in message_history:
        mapped_role = "user" if msg["role"] in ["hm", "system"] else "model"
        gemini_history.append({"role": mapped_role, "parts": [{"text": msg["content"]}]})

    history_text_for_prompt = "\n".join([f"{'Hiring Manager' if m['role']=='hm' else ('User Applicant' if m['role']=='user_applicant' else ('AI Applicant' if m['role']=='ai_applicant' else 'System'))}: {m['content']}"
                                         for m in message_history])
    if not history_text_for_prompt: history_text_for_prompt = "The negotiation begins."

    full_context_prompt = agent_prompt.replace("[History will be inserted here by the calling function]", history_text_for_prompt)
    final_api_payload_contents = gemini_history + [{"role": "user", "parts": [{"text": full_context_prompt}]}]

    payload = {
        "contents": final_api_payload_contents,
        "generationConfig": {
            "temperature": 0.6, # Lower temp for more controlled, assertive tone
            "maxOutputTokens": 450, # Allow slightly longer responses if needed for firmness
            "topP": 0.95,
            "topK": 40
        },
        "safetySettings": [
            {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
            {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
            {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
            {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
        ]
    }
    url = f"{BASE_URL}?key={API_KEY}"

    try:
        response = requests.post(url, headers=HEADERS, json=payload, timeout=60)
        response.raise_for_status()
        response_data = response.json()

        if not response_data.get("candidates"):
            block_reason = response_data.get("promptFeedback", {}).get("blockReason", "Unknown reason")
            print(f"⚠️ Gemini Warning ({agent_id_for_log}): Prompt blocked due to {block_reason}.")
            return f"({agent_id_for_log}'s response was blocked: {block_reason}.)"

        candidate = response_data["candidates"][0]

        # Check finish reason first
        finish_reason = candidate.get("finishReason")
        if finish_reason and finish_reason != "STOP":
             print(f"⚠️ Gemini Warning ({agent_id_for_log}): Generation finished due to {finish_reason}.")
             # If safety, provide more info if available
             if finish_reason == "SAFETY" and "safetyRatings" in candidate:
                 print(f"   Safety Ratings: {candidate['safetyRatings']}")
                 return f"({agent_id_for_log}'s response stopped due to: SAFETY.)"
             # Allow MAX_TOKENS through if content exists
             if finish_reason == "MAX_TOKENS" and candidate.get("content", {}).get("parts"):
                  pass # Continue below to extract content
             else:
                  return f"({agent_id_for_log}'s response stopped due to: {finish_reason}.)"


        # Extract content
        if candidate.get("content", {}).get("parts"):
            generated_text = candidate["content"]["parts"][0].get("text", "").strip()
            if generated_text:
                generated_text = re.sub(r'^(AI Job Seeker|Hiring Manager|User Applicant):\s*', '', generated_text).strip()
                return generated_text
            else:
                 print(f"⚠️ Gemini Warning ({agent_id_for_log}): Received empty text part.")
                 return f"({agent_id_for_log} generated an empty response.)"

        print(f"❌ Gemini Error ({agent_id_for_log}): No content found. Finish Reason: {finish_reason}. Response: {response_data}")
        return f"({agent_id_for_log} received response with no content. Finish: {finish_reason})"

    except requests.exceptions.RequestException as e:
        print(f"❌ API Request Error ({agent_id_for_log}): {e}")
        error_detail = "Network/API Error"
        if isinstance(e, requests.exceptions.Timeout): error_detail = "Timeout"
        elif isinstance(e, requests.exceptions.HTTPError):
            status_code = e.response.status_code
            error_detail = f"HTTP Error {status_code}"
            try: error_msg = e.response.json()['error']['message']
            except: error_msg = e.response.text
            print(f"   Error details: {error_msg}")
            if status_code == 400: error_detail += " (Bad Request - Check API Key/Format)"
            elif status_code == 403: error_detail += " (Forbidden - Check API Key Permissions/Billing)"
            elif status_code == 429: error_detail += " (Quota Exceeded)"
            elif status_code >= 500: error_detail += " (Server Error)"

        return f"({agent_id_for_log} API Error: {error_detail}.)"
    except Exception as e:
        print(f"❌ Unexpected Error during API call ({agent_id_for_log}): {e}")
        return f"({agent_id_for_log} encountered an unexpected error.)"

# --- Utility Functions ---
def extract_salary_figure(text: str) -> Optional[int]:
    """Extracts the most likely salary figure from a string."""
    numbers = re.findall(r'\$?(\d{1,3}(?:[,.]\d{3})*|\d+)\s?(k|thousand|usd|dollars)?', text, re.IGNORECASE)
    potential_salaries = []
    for num_str, suffix in numbers:
        try:
            num_str = num_str.replace(',', '')
            if '.' in num_str and not re.match(r'\d{1,3}(\.\d{3})+$', num_str.replace('$', '')):
                 num_val = float(num_str)
            else:
                 num_str = num_str.replace('.', '')
                 num_val = int(num_str)
            if suffix and suffix.lower() in ['k', 'thousand']: num_val *= 1000
            if 20000 < num_val < 500000: potential_salaries.append(int(round(num_val)))
        except ValueError: continue
    return max(potential_salaries) if potential_salaries else None

def parse_final_decision(text: str, min_acceptable: int, last_offer: Optional[int]) -> Tuple[str, Optional[int], str]:
    """Parses final acceptance/rejection. Returns verdict, salary, conclusion_message."""
    text_lower = text.lower()
    accepted, rejected = False, False
    verdict_reason = ""

    if "[acceptance]" in text_lower: accepted, verdict_reason = True, "Accepted (Flag)"
    elif "[leave the room]" in text_lower: rejected, verdict_reason = True, "Rejected (Flag)"

    accept_kws = ["i accept", "accepted", "deal", "agree", "let's do it", "i take the offer"]
    reject_kws = ["i reject", "rejected", "i decline", "cannot accept", "must decline", "no thank you"]

    if not accepted and not rejected:
        if any(kw in text_lower for kw in accept_kws): accepted, verdict_reason = True, "Accepted (Keyword)"
        elif any(kw in text_lower for kw in reject_kws): rejected, verdict_reason = True, "Rejected (Keyword)"

    if not accepted and not rejected: # Implicit decision
        if last_offer is not None and last_offer >= min_acceptable:
             accepted, verdict_reason = True, "Accepted (Implicit)"
        else:
             rejected, verdict_reason = True, "Rejected (Implicit/Low Offer)"

    if accepted:
        salary = extract_salary_figure(text) or last_offer
        if salary and salary >= min_acceptable:
            conclusion = f"--- Negotiation Concluded: ACCEPTED (Salary: ${salary:,}) ({verdict_reason}) ---"
            return "Accepted", salary, conclusion
        else:
            conclusion = f"--- Negotiation Concluded: FAILED (Invalid Acceptance Salary: {salary}) ---"
            return "Failed (Accepted Invalid)", None, conclusion
    elif rejected:
         conclusion = f"--- Negotiation Concluded: REJECTED ({verdict_reason}) ---"
         return "Rejected", None, conclusion
    else: # Fallback
        conclusion = "--- Negotiation Concluded: FAILED (Ambiguous Outcome) ---"
        return "Failed (Ambiguous)", None, conclusion

def determine_winner(user_verdict, user_salary, ai_verdict, ai_salary):
    """Determines the winner based on negotiation outcomes."""
    user_success = user_verdict == "Accepted" and user_salary is not None
    ai_success = ai_verdict == "Accepted" and ai_salary is not None
    if user_verdict == "Rejected (HM Left)": user_success = False
    if ai_verdict == "Rejected (HM Left)": ai_success = False

    if user_success and ai_success:
        if user_salary > ai_salary: return f"🏆 YOU WIN! You secured ${user_salary:,}, crushing the AI's ${ai_salary:,}!"
        elif ai_salary > user_salary: return f"🤖 AI WINS! The AI strategist negotiated ${ai_salary:,}, outplaying your ${user_salary:,}."
        else: return f"🤝 IT'S A TIE! Both settled for ${user_salary:,}."
    elif user_success and not ai_success: return f"🏆 YOU WIN! You closed the deal at ${user_salary:,}! The AI failed ({ai_verdict})."
    elif not user_success and ai_success: return f"🤖 AI WINS! The AI secured ${ai_salary:,}! You failed ({user_verdict})."
    else:
         if user_verdict == "Rejected (HM Left)" and ai_verdict == "Rejected (HM Left)": return f"⚖️ STALEMATE! The Hiring Manager walked away from both negotiations!"
         else: return f"⚖️ NO WINNER! Neither reached an agreement. (You: {user_verdict}, AI: {ai_verdict})"

# --- UI Styling ---
theme = gr.themes.Soft(
    primary_hue=gr.themes.colors.blue,
    secondary_hue=gr.themes.colors.sky,
    neutral_hue=gr.themes.colors.slate
)

# --- Gradio UI and Logic ---
with gr.Blocks(theme=theme, title="Salary Showdown: Human vs. AI", css=".gradio-container { max-width: 95% !important; } #winner-display {text-align: center; font-size: 1.5em;}") as demo:

    # --- Game State Variables ---
    profile_state = gr.State({})
    ideal_salary_state = gr.State(0)
    min_acceptable_salary_state = gr.State(0)
    hm_max_budget_state = gr.State(0)

    user_message_history_state = gr.State([])
    user_turn_number_state = gr.State(0)
    user_negotiation_finished_state = gr.State(False)
    user_final_verdict_state = gr.State("")
    user_final_salary_state = gr.State(None)

    ai_message_history_state = gr.State([])
    ai_negotiation_finished_state = gr.State(False)
    ai_final_verdict_state = gr.State("")
    ai_final_salary_state = gr.State(None)

    game_phase_state = gr.State("setup") # 'setup', 'user_negotiating', 'user_done', 'ai_simulating', 'results'

    # --- UI Layout ---
    gr.Markdown("# 💸 Salary Showdown: Human vs. AI 🤖", elem_id="main-title")
    gr.Markdown("Negotiate against our AI Hiring Manager. Can you secure a better deal than our AI Applicant?", elem_id="subtitle")

    with gr.Tabs() as tabs:
        # --- Tab 1: Setup ---
        with gr.TabItem("👤 1. Setup Your Profile", id=0):
            with gr.Row():
                with gr.Column(scale=2):
                    gr.Markdown("### Your Candidate Persona")
                    default_profile = generate_random_profile_defaults()
                    profile_age_input = gr.Number(label="Age", value=default_profile['age'], minimum=18, maximum=70, step=1)
                    profile_gender_input = gr.Radio(label="Gender", choices=["Male", "Female", "Other"], value=default_profile['gender'])
                    profile_education_input = gr.Dropdown(label="Highest Education Level", choices=["High School", "Bachelor's", "Master's", "PhD"], value=default_profile['education'])
                    profile_job_title_input = gr.Dropdown(label="Target Job Title", choices=CLEANED_JOB_TITLES, value=default_profile['job_title'], filterable=True)
                    profile_yoe_input = gr.Number(label="Years of Relevant Experience", value=default_profile['yoe'], minimum=0, maximum=50, step=1)
                    generate_profile_btn = gr.Button("🎲 Randomize Profile")
                with gr.Column(scale=1):
                    gr.Markdown("### Game Start")
                    start_game_btn = gr.Button("🚀 Start Negotiation Game!", variant="primary", size="lg")
                    game_setup_status = gr.Markdown("Configure your profile and click 'Start'.")
                    salary_info_display = gr.Markdown("", visible=False) # To show predicted/min salary

            def update_profile_inputs():
                new_defaults = generate_random_profile_defaults()
                return {
                    profile_age_input: gr.update(value=new_defaults['age']),
                    profile_gender_input: gr.update(value=new_defaults['gender']),
                    profile_education_input: gr.update(value=new_defaults['education']),
                    profile_job_title_input: gr.update(value=new_defaults['job_title']),
                    profile_yoe_input: gr.update(value=new_defaults['yoe'])
                }
            generate_profile_btn.click(fn=update_profile_inputs, inputs=[], outputs=[profile_age_input, profile_gender_input, profile_education_input, profile_job_title_input, profile_yoe_input])

        # --- Tab 2: Your Negotiation ---
        with gr.TabItem("💬 2. Your Negotiation", id=1):
            user_negotiation_status = gr.Markdown("Status: Waiting to start...")
            user_chatbot_display = gr.Chatbot(
                label="Negotiation Transcript (You vs. AI HM)", height=500, show_copy_button=True, bubble_full_width=False, render=False,
                avatar_images=(None, "https://img.icons8.com/fluency/96/manager.png")
            )
            user_chatbot_display.render()
            with gr.Row():
                user_message_input = gr.Textbox(label="Your Message:", placeholder="Type your response...", interactive=False, scale=4, lines=2)
                send_message_btn = gr.Button("✉️ Send", interactive=False, scale=1, variant="secondary")
            with gr.Row():
                accept_now_btn = gr.Button("✅ Accept Current Offer", variant="primary", interactive=False)
                with gr.Row(visible=False) as final_decision_buttons:
                     accept_offer_btn = gr.Button("✅ ACCEPT Final Offer", variant="primary")
                     reject_offer_btn = gr.Button("❌ REJECT Final Offer", variant="stop")
            user_decision_input = gr.Textbox(label="Decision", visible=False)
            see_ai_negotiate_btn = gr.Button("🤖 See AI Applicant Negotiate", visible=False, variant="primary") # New button

        # --- Tab 3: AI Simulation & Results ---
        with gr.TabItem("🏆 3. AI Simulation & Results", id=2):
            results_status = gr.Markdown("Complete your negotiation first, then watch the AI.")
            ai_sim_chatbot_display = gr.Chatbot(
                label="AI Applicant vs AI HM Simulation", height=400, show_copy_button=True, bubble_full_width=False, render=False,
                avatar_images=("https://img.icons8.com/fluency/96/manager.png", "https://img.icons8.com/fluency/96/robot-3.png")
            )
            ai_sim_chatbot_display.render()
            winner_display = gr.Markdown("### Winner will be decided after AI simulation...", elem_id="winner-display")
            with gr.Row(equal_height=False):
                with gr.Column(scale=1):
                    gr.Markdown("#### Your Negotiation Summary")
                    user_result_display = gr.Textbox(label="Your Result:", lines=4, interactive=False, container=False)
                with gr.Column(scale=1):
                    gr.Markdown("#### AI Applicant Summary")
                    ai_result_display = gr.Textbox(label="AI Result:", lines=4, interactive=False, container=False)
            reset_game_btn = gr.Button("🔄 Play Again (New Profile)", variant="primary", size="lg", visible=False)


    # --- Helper Functions ---
    def format_chatbot_history(message_history: List[Dict[str, str]], user_role: str = "user_applicant") -> List[Tuple[Optional[str], Optional[str]]]:
        """Converts internal message history to Gradio chatbot format."""
        gradio_history = []
        for msg in message_history:
            role = msg.get("role")
            content = msg.get("content", "")
            style = ""
            if role == "system" and "--- Negotiation Concluded:" in content:
                if "ACCEPTED" in content: style = "color:green; font-weight:bold;"
                elif "REJECTED" in content or "FAILED" in content or "Left" in content or "Error" in content: style = "color:red; font-weight:bold;"
                else: style = "font-weight:bold;"
                content = f"<p style='{style}'>{content}</p>"
                gradio_history.append((content, None))
            elif role == "hm": gradio_history.append((content, None))
            elif role == user_role: gradio_history.append((None, content))
            elif role != "system": gradio_history.append((f"({role}): {content}", None))
        return gradio_history

    def generate_user_status_markdown(turn_num, max_turns, min_acceptable, hm_max_budget, finished_reason=None) -> str:
        """Generates the status markdown for the user negotiation tab."""
        status = f"**Your Goal:** Beat the AI! | **Your Minimum:** <span style='color: red;'>${min_acceptable:,}</span> | **HM Max Budget:** <span style='color: orange;'>${hm_max_budget:,}</span>\n"
        status += f"**Turn:** {turn_num} / {max_turns} | "
        if finished_reason:
            if "Accepted" in finished_reason: icon = "✅"
            elif "Rejected (HM Left)" in finished_reason: icon = "🚶‍♂️"
            elif "Rejected" in finished_reason: icon = "❌"
            else: icon = "⚠️"
            status += f"**Your Negotiation Result:** {icon} **{finished_reason}**"
        elif turn_num == HM_FINAL_OFFER_TURN: status += "⏳ _Waiting for HM's **Final Offer**..._"
        elif turn_num == APPLICANT_FINAL_DECISION_TURN: status += "**🔥 YOUR FINAL DECISION!**"
        elif turn_num % 2 == 1: status += "⏳ _Waiting for Hiring Manager..._"
        else: status += "👉 **YOUR TURN!**"
        return status

    # --- Core Game Logic ---

    def run_start_game(age, gender, education, job_title, yoe):
        """Initializes the game state."""
        print("\n--- Starting New Game ---")
        profile = {"age": int(age), "gender": gender, "education": education, "job_title": job_title, "yoe": int(yoe)}
        print(f"Profile: {profile}")

        ideal_salary = predict_salary_from_profile(profile['age'], profile['gender'], profile['education'], profile['job_title'], profile['yoe'])
        min_acceptable = round(ideal_salary * 0.88 / 1000) * 1000
        hm_max_budget = int(ideal_salary * random.uniform(1.01, 1.09)) # Tighter budget for HM

        print(f"Ideal Salary: ${ideal_salary:,}, Min Acceptable: ${min_acceptable:,}, HM Max Budget: ${hm_max_budget:,}")

        initial_hm_prompt = get_hiring_manager_prompt(profile, ideal_salary, hm_max_budget, False, "User")
        initial_hm_prompt += "\n Begin the negotiation. Welcome the candidate briefly and state your initial position or offer."
        first_hm_message = call_gemini(initial_hm_prompt, [], "HM (Opening)")

        if "API Error" in first_hm_message or "blocked" in first_hm_message:
             print(f"API Error on initial HM call: {first_hm_message}")
             return { game_setup_status: gr.update(value=f"❌ ERROR starting game: {first_hm_message}") }

        initial_user_history = [{"role": "hm", "content": first_hm_message}]
        user_turn = 2
        user_status = generate_user_status_markdown(user_turn, MAX_TURNS_TOTAL, min_acceptable, hm_max_budget)
        user_chat = format_chatbot_history(initial_user_history, "user_applicant")
        salary_info = f"**Salary Intel:** Market Estimate: **~${ideal_salary:,}** | Your Minimum: **${min_acceptable:,}** | HM's Max Budget: **${hm_max_budget:,}**"

        print("--- Game Initialized ---")
        return {
            profile_state: profile, ideal_salary_state: ideal_salary, min_acceptable_salary_state: min_acceptable, hm_max_budget_state: hm_max_budget,
            user_message_history_state: initial_user_history, user_turn_number_state: user_turn,
            user_negotiation_finished_state: False, user_final_verdict_state: "", user_final_salary_state: None,
            ai_message_history_state: [], ai_negotiation_finished_state: False, ai_final_verdict_state: "", ai_final_salary_state: None,
            game_phase_state: "user_negotiating",

            game_setup_status: gr.update(value="✅ Game started! Proceed to 'Your Negotiation' tab."),
            salary_info_display: gr.update(value=salary_info, visible=True),
            start_game_btn: gr.update(interactive=False), profile_age_input: gr.update(interactive=False),
            profile_gender_input: gr.update(interactive=False), profile_education_input: gr.update(interactive=False),
            profile_job_title_input: gr.update(interactive=False), profile_yoe_input: gr.update(interactive=False),
            generate_profile_btn: gr.update(interactive=False),

            tabs: gr.update(selected=1), user_negotiation_status: user_status, user_chatbot_display: user_chat,
            user_message_input: gr.update(interactive=True, value="", placeholder="Type your response..."),
            send_message_btn: gr.update(interactive=True), accept_now_btn: gr.update(interactive=True),
            final_decision_buttons: gr.update(visible=False), see_ai_negotiate_btn: gr.update(visible=False),

            results_status: gr.update(value="Your negotiation is in progress..."), ai_sim_chatbot_display: None,
            winner_display: gr.update(value="### Winner decided after AI sim..."), user_result_display: "", ai_result_display: "",
            reset_game_btn: gr.update(visible=False)
        }
    start_game_btn.click(
        fn=run_start_game,
        inputs=[profile_age_input, profile_gender_input, profile_education_input, profile_job_title_input, profile_yoe_input],
        outputs=[
            profile_state, ideal_salary_state, min_acceptable_salary_state, hm_max_budget_state,
            user_message_history_state, user_turn_number_state, user_negotiation_finished_state, user_final_verdict_state, user_final_salary_state,
            ai_message_history_state, ai_negotiation_finished_state, ai_final_verdict_state, ai_final_salary_state, game_phase_state,
            game_setup_status, salary_info_display, start_game_btn, profile_age_input, profile_gender_input, profile_education_input, profile_job_title_input, profile_yoe_input, generate_profile_btn,
            tabs, user_negotiation_status, user_chatbot_display, user_message_input, send_message_btn, accept_now_btn, final_decision_buttons, see_ai_negotiate_btn,
            results_status, ai_sim_chatbot_display, winner_display, user_result_display, ai_result_display, reset_game_btn
        ]
    )

    def conclude_user_negotiation(conclusion_history, conclusion_turn, verdict, salary):
        """Helper to finalize user negotiation state and UI."""
        final_user_status = generate_user_status_markdown(conclusion_turn, MAX_TURNS_TOTAL, min_acceptable_salary_state.value, hm_max_budget_state.value, verdict)
        formatted_history = format_chatbot_history(conclusion_history, user_role="user_applicant")
        user_summary = f"Outcome: {verdict}\n"
        user_summary += f"Final Salary: ${salary:,}" if salary else "Final Salary: N/A"

        return {
            user_message_history_state: conclusion_history, user_turn_number_state: conclusion_turn + 1,
            user_negotiation_finished_state: True, user_final_verdict_state: verdict, user_final_salary_state: salary,
            game_phase_state: "user_done", # New phase indicating user finished, AI sim pending
            user_negotiation_status: final_user_status, user_chatbot_display: formatted_history,
            user_message_input: gr.update(interactive=False, value="", placeholder="Negotiation Concluded."),
            send_message_btn: gr.update(interactive=False), accept_now_btn: gr.update(interactive=False),
            final_decision_buttons: gr.update(visible=False),
            see_ai_negotiate_btn: gr.update(visible=True, interactive=True), # Activate the button
            results_status: gr.update(value="Your negotiation finished. Click 'See AI Negotiate' to proceed."), # Update status
            user_result_display: gr.update(value=user_summary) # Show user summary immediately
        }

    def run_user_turn(user_message, current_profile, current_ideal_salary, current_min_acceptable, current_hm_max,
                      current_user_history, current_user_turn, is_user_finished, decision_type):

        if is_user_finished or not current_profile: return {}
        print(f"\n--- User Turn Start --- (Turn: {current_user_turn})")

        updated_user_history = current_user_history.copy()
        user_verdict, user_salary, conclusion_message = "", None, ""
        user_finished_this_turn = False
        next_turn_number = current_user_turn + 1
        is_final_user_decision = (current_user_turn == APPLICANT_FINAL_DECISION_TURN)

        # --- Process User Input / Final Decision ---
        if is_final_user_decision:
            user_input = "Based on the final offer, I accept." if decision_type == "accept" else \
                         "Thank you for the final offer, but I must decline." if decision_type == "reject" else \
                         user_message.strip() if user_message else "(No final decision message)"
            print(f"User final input: {user_input}")
            last_hm_offer_msg = next((msg for msg in reversed(updated_user_history) if msg["role"] == "hm"), None)
            last_hm_offer = extract_salary_figure(last_hm_offer_msg['content']) if last_hm_offer_msg else None
            user_verdict, user_salary, conclusion_message = parse_final_decision(user_input, current_min_acceptable, last_hm_offer)
            updated_user_history.append({"role": "user_applicant", "content": user_input})
            user_finished_this_turn = True
        else:
            user_input = user_message.strip()
            if not user_input: return { user_message_input: gr.update(placeholder="Response cannot be empty.") }
            print(f"User message: {user_input}")
            updated_user_history.append({"role": "user_applicant", "content": user_input})

        # --- Conclude if User Finished ---
        if user_finished_this_turn:
            print(f"User negotiation concluded by user's decision. Verdict: {user_verdict}")
            updated_user_history.append({"role": "system", "content": conclusion_message})
            return conclude_user_negotiation(updated_user_history, current_user_turn, user_verdict, user_salary)

        # --- Get HM Response ---
        print(f"--- Getting HM Response (Turn: {next_turn_number}) ---")
        is_hm_final_offer = (next_turn_number == HM_FINAL_OFFER_TURN)
        hm_prompt = get_hiring_manager_prompt(current_profile, current_ideal_salary, current_hm_max, is_hm_final_offer, "User")
        hm_response = call_gemini(hm_prompt, updated_user_history, "HM (Responding to User)")

        if "API Error" in hm_response or "blocked" in hm_response:
             print(f"API Error on HM response: {hm_response}")
             error_msg = f"--- Negotiation Failed: API Error on HM Turn {next_turn_number} ({hm_response}) ---"
             updated_user_history.append({"role": "system", "content": error_msg})
             return conclude_user_negotiation(updated_user_history, next_turn_number, f"Failed (API Error)", None)

        hm_finished_this_turn = False
        hm_conclusion_message = ""
        if "[leave the room]" in hm_response.lower():
            user_verdict, user_salary, hm_finished_this_turn = "Rejected (HM Left)", None, True
            hm_conclusion_message = "--- Negotiation Concluded: REJECTED (Hiring Manager Ended Discussion) ---"
            print("HM left the negotiation.")
            hm_response = re.sub(r'\[leave the room\]', '', hm_response, flags=re.IGNORECASE).strip()
        elif "[acceptance confirmed]" in hm_response.lower():
            user_verdict = "Accepted"
            user_salary = extract_salary_figure(hm_response) or extract_salary_figure(user_input)
            if not user_salary: # Fallback
                 last_hm_offer_msg = next((msg for msg in reversed(updated_user_history[:-1]) if msg["role"] == "hm"), None)
                 user_salary = extract_salary_figure(last_hm_offer_msg['content']) if last_hm_offer_msg else None
            hm_finished_this_turn = True
            sal_str = f"${user_salary:,}" if user_salary else "N/A"
            hm_conclusion_message = f"--- Negotiation Concluded: ACCEPTED (Salary: {sal_str}) (HM Confirmed) ---"
            print(f"HM confirmed acceptance. Salary: {sal_str}")
            hm_response = re.sub(r'\[acceptance confirmed\]', '', hm_response, flags=re.IGNORECASE).strip()

        updated_user_history.append({"role": "hm", "content": hm_response})
        final_turn_next_user = next_turn_number + 1

        # --- Conclude if HM Finished or Max Turns Reached ---
        if hm_finished_this_turn:
            print("User negotiation concluded by HM action.")
            updated_user_history.append({"role": "system", "content": hm_conclusion_message})
            return conclude_user_negotiation(updated_user_history, next_turn_number, user_verdict, user_salary)

        elif final_turn_next_user > MAX_TURNS_TOTAL:
             print("User negotiation concluded: Max turns.")
             last_hm_offer_msg = next((msg for msg in reversed(updated_user_history) if msg["role"] == "hm"), None)
             last_hm_offer = extract_salary_figure(last_hm_offer_msg['content']) if last_hm_offer_msg else None
             max_v, max_s, max_c = parse_final_decision("(Max turns)", current_min_acceptable, last_hm_offer)
             max_v = f"{max_v} (Max Turns)"
             max_c = max_c.replace("Negotiation Concluded", f"Negotiation Concluded ({max_v})")
             updated_user_history.append({"role": "system", "content": max_c})
             return conclude_user_negotiation(updated_user_history, MAX_TURNS_TOTAL, max_v, max_s)

        # --- Prepare UI for next user turn ---
        show_final_btns = (final_turn_next_user == APPLICANT_FINAL_DECISION_TURN)
        user_status = generate_user_status_markdown(final_turn_next_user, MAX_TURNS_TOTAL, current_min_acceptable, current_hm_max)
        formatted_hist = format_chatbot_history(updated_user_history, "user_applicant")

        print(f"--- User Turn End --- (Next User Action: Turn {final_turn_next_user})")
        return {
            user_message_history_state: updated_user_history, user_turn_number_state: final_turn_next_user,
            user_negotiation_finished_state: False, user_decision_input: "",
            user_negotiation_status: user_status, user_chatbot_display: formatted_hist,
            user_message_input: gr.update(value="", placeholder="Type response..." if not show_final_btns else "Use buttons or type final decision", interactive=True),
            send_message_btn: gr.update(interactive=not show_final_btns),
            accept_now_btn: gr.update(interactive=True, value="✅ Accept Current Offer"),
            final_decision_buttons: gr.update(visible=show_final_btns)
        }

    def run_user_accept_offer(current_user_history, current_min_acceptable, current_user_turn):
        """Handles the 'Accept Current Offer' button."""
        if not current_user_history: return {}
        print(f"\n--- User clicked ACCEPT NOW (Turn: {current_user_turn}) ---")

        last_hm_offer_msg = next((msg for msg in reversed(current_user_history) if msg["role"] == "hm"), None)
        last_hm_offer = extract_salary_figure(last_hm_offer_msg['content']) if last_hm_offer_msg else None

        if last_hm_offer is None:
             print("Accept Now failed: No offer found.")
             return {accept_now_btn: gr.update(value="No Offer Found", interactive=False)}

        print(f"Last HM offer: ${last_hm_offer:,}. Min: ${current_min_acceptable:,}")

        if last_hm_offer >= current_min_acceptable:
             print("Offer acceptable. Concluding.")
             accept_msg = f"Okay, I accept the current offer of ${last_hm_offer:,}."
             conclusion_msg = f"--- Negotiation Concluded: ACCEPTED (Salary: ${last_hm_offer:,}) (User Accepted Offer) ---"
             updated_history = current_user_history + [{"role": "user_applicant", "content": accept_msg}, {"role": "system", "content": conclusion_msg}]
             return conclude_user_negotiation(updated_history, current_user_turn, "Accepted", last_hm_offer)
        else:
             print("Accept Now failed: Offer below minimum.")
             return {accept_now_btn: gr.update(value=f"Offer (${last_hm_offer:,}) < Min!", interactive=True)}

    # --- Event Listeners ---
    accept_now_btn.click(
        fn=run_user_accept_offer,
        inputs=[user_message_history_state, min_acceptable_salary_state, user_turn_number_state],
        outputs=[
            user_message_history_state, user_turn_number_state, user_negotiation_finished_state, user_final_verdict_state, user_final_salary_state,
            game_phase_state, user_negotiation_status, user_chatbot_display, user_message_input, send_message_btn, accept_now_btn, final_decision_buttons,
            see_ai_negotiate_btn, results_status, user_result_display
        ]
    )
    send_message_btn.click(
        fn=run_user_turn,
        inputs=[user_message_input, profile_state, ideal_salary_state, min_acceptable_salary_state, hm_max_budget_state, user_message_history_state, user_turn_number_state, user_negotiation_finished_state, user_decision_input],
        outputs=[
            user_message_history_state, user_turn_number_state, user_negotiation_finished_state, user_final_verdict_state, user_final_salary_state,
            game_phase_state, user_decision_input, user_negotiation_status, user_chatbot_display, user_message_input, send_message_btn, accept_now_btn, final_decision_buttons,
            see_ai_negotiate_btn, results_status, user_result_display
        ]
    ).then(lambda: {"value": ""}, outputs=[user_message_input])
    user_message_input.submit(
         fn=run_user_turn,
        inputs=[user_message_input, profile_state, ideal_salary_state, min_acceptable_salary_state, hm_max_budget_state, user_message_history_state, user_turn_number_state, user_negotiation_finished_state, user_decision_input],
        outputs=[
            user_message_history_state, user_turn_number_state, user_negotiation_finished_state, user_final_verdict_state, user_final_salary_state,
            game_phase_state, user_decision_input, user_negotiation_status, user_chatbot_display, user_message_input, send_message_btn, accept_now_btn, final_decision_buttons,
            see_ai_negotiate_btn, results_status, user_result_display
        ]
    ).then(lambda: {"value": ""}, outputs=[user_message_input])
    accept_offer_btn.click(lambda: "accept", outputs=[user_decision_input]).then(
        fn=run_user_turn,
        inputs=[user_message_input, profile_state, ideal_salary_state, min_acceptable_salary_state, hm_max_budget_state, user_message_history_state, user_turn_number_state, user_negotiation_finished_state, user_decision_input],
        outputs=[
            user_message_history_state, user_turn_number_state, user_negotiation_finished_state, user_final_verdict_state, user_final_salary_state,
            game_phase_state, user_decision_input, user_negotiation_status, user_chatbot_display, user_message_input, send_message_btn, accept_now_btn, final_decision_buttons,
            see_ai_negotiate_btn, results_status, user_result_display
        ]
    )
    reject_offer_btn.click(lambda: "reject", outputs=[user_decision_input]).then(
        fn=run_user_turn,
         inputs=[user_message_input, profile_state, ideal_salary_state, min_acceptable_salary_state, hm_max_budget_state, user_message_history_state, user_turn_number_state, user_negotiation_finished_state, user_decision_input],
        outputs=[
             user_message_history_state, user_turn_number_state, user_negotiation_finished_state, user_final_verdict_state, user_final_salary_state,
            game_phase_state, user_decision_input, user_negotiation_status, user_chatbot_display, user_message_input, send_message_btn, accept_now_btn, final_decision_buttons,
            see_ai_negotiate_btn, results_status, user_result_display
        ]
    )

    # --- AI Simulation Logic (Generator for delayed display) ---
    def run_ai_simulation_generator(current_profile, current_ideal_salary, current_min_acceptable, current_hm_max):
        """Generator function to run AI simulation step-by-step with delay."""
        print("\n--- Starting AI Simulation Generator ---")
        yield { # Initial UI update
            see_ai_negotiate_btn: gr.update(interactive=False, value="Simulating..."),
            tabs: gr.update(selected=2), # Switch to results tab
            results_status: gr.update(value="⏳ Running AI vs AI simulation..."),
            ai_sim_chatbot_display: gr.update(value=[]) # Clear previous sim if any
        }

        if not current_profile:
            print("AI Sim Error: Profile missing.")
            yield {
                 results_status: gr.update(value="❌ Error: Profile data missing for AI simulation."),
                 ai_negotiation_finished_state: True, ai_final_verdict_state: "Error (No Profile)"
            }
            return

        ai_history = []
        current_turn = 1
        sim_verdict, sim_salary = "Failed (Unknown)", None
        sim_finished = False
        next_caller = 'hm'
        ai_min = current_min_acceptable
        conclusion_msg = ""

        while current_turn <= MAX_TURNS_TOTAL and not sim_finished:
            print(f"   AI Sim Turn: {current_turn}, Caller: {next_caller}")
            yield {results_status: gr.update(value=f"⏳ Simulating AI Turn {current_turn}/{MAX_TURNS_TOTAL} ({next_caller.upper()})...")}
            time.sleep(5) # Wait 5 seconds

            is_final_ai = (current_turn == APPLICANT_FINAL_DECISION_TURN and next_caller == 'ai')
            is_final_hm = (current_turn == HM_FINAL_OFFER_TURN and next_caller == 'hm')
            content, role = "", ""

            try:
                if next_caller == 'hm':
                    prompt = get_hiring_manager_prompt(current_profile, current_ideal_salary, current_hm_max, is_final_hm, "AI Applicant")
                    if current_turn == 1: prompt += "\n Begin negotiation with the AI Applicant."
                    content = call_gemini(prompt, ai_history, "HM (Sim)")
                    role = "hm"
                    next_caller = 'ai'
                    if "API Error" in content or "blocked" in content: raise Exception(f"API Error HM (Sim): {content}")

                    if "[leave the room]" in content.lower():
                        sim_verdict, sim_finished = "Rejected (HM Left)", True
                        conclusion_msg = "--- Negotiation Concluded: REJECTED (HM Ended Discussion) ---"
                        content = re.sub(r'\[leave the room\]', '', content, flags=re.IGNORECASE).strip()
                    # Acceptance confirmation by HM is unlikely with this AI but handle defensively
                    elif "[acceptance confirmed]" in content.lower():
                        sim_verdict = "Accepted"
                        sim_salary = extract_salary_figure(content) or extract_salary_figure(ai_history[-1]['content'] if ai_history else "")
                        sim_finished = True
                        conclusion_msg = f"--- Negotiation Concluded: ACCEPTED (Salary: ${sim_salary:,}) (HM Confirmed) ---"
                        content = re.sub(r'\[acceptance confirmed\]', '', content, flags=re.IGNORECASE).strip()

                else: # next_caller == 'ai'
                    prompt = get_ai_applicant_prompt(current_profile, current_ideal_salary, ai_min, is_final_ai)
                    content = call_gemini(prompt, ai_history, "AI Applicant (Sim)")
                    role = "ai_applicant"
                    next_caller = 'hm'
                    if "API Error" in content or "blocked" in content: raise Exception(f"API Error AI Applicant (Sim): {content}")

                    if "[acceptance]" in content.lower():
                        last_hm = next((msg for msg in reversed(ai_history) if msg["role"] == "hm"), None)
                        offer = extract_salary_figure(last_hm['content']) if last_hm else None
                        salary = extract_salary_figure(content) or offer
                        if salary and salary >= ai_min:
                            sim_verdict, sim_salary, conclusion_msg = "Accepted", salary, f"--- Concluded: ACCEPTED (Salary: ${salary:,}) (AI Accepted) ---"
                        else:
                            sim_verdict, sim_salary, conclusion_msg = "Failed (Accepted Invalid)", None, f"--- Concluded: FAILED (AI Accepted Invalid Sal: {salary}) ---"
                        sim_finished = True
                        content = re.sub(r'\[acceptance\]', '', content, flags=re.IGNORECASE).strip()
                    elif "[leave the room]" in content.lower():
                        if is_final_ai:
                            sim_verdict, sim_salary, conclusion_msg = "Rejected", None, "--- Concluded: REJECTED (AI Rejected Final Offer) ---"
                            sim_finished = True
                            content = re.sub(r'\[leave the room\]', '', content, flags=re.IGNORECASE).strip()
                        else: # AI shouldn't leave early
                            content = re.sub(r'\[leave the room\]', '', content, flags=re.IGNORECASE).strip()
                    elif is_final_ai and not sim_finished: # Implicit final decision
                         last_hm = next((msg for msg in reversed(ai_history) if msg["role"] == "hm"), None)
                         offer = extract_salary_figure(last_hm['content']) if last_hm else None
                         sim_verdict, sim_salary, conclusion_msg = parse_final_decision("(AI Final Implicit)", ai_min, offer)
                         sim_finished = True

            except Exception as e:
                 print(f"❌ Error in AI sim turn {current_turn}: {e}")
                 sim_verdict, sim_salary, conclusion_msg = f"Error (Turn {current_turn})", None, f"--- Simulation Failed: Error on Turn {current_turn} ---"
                 sim_finished = True
                 ai_history.append({"role": "system", "content": f"Sim error: {e}"})

            if content and role: ai_history.append({"role": role, "content": content})
            if sim_finished and conclusion_msg: ai_history.append({"role": "system", "content": conclusion_msg})

            # Yield the updated history for chatbot display
            yield {ai_sim_chatbot_display: gr.update(value=format_chatbot_history(ai_history, "ai_applicant"))}

            current_turn += 1

        # Final check after loop (max turns)
        if not sim_finished:
            print("AI sim concluded: Max turns.")
            last_hm = next((msg for msg in reversed(ai_history) if msg["role"] == "hm"), None)
            offer = extract_salary_figure(last_hm['content']) if last_hm else None
            sim_verdict, sim_salary, conclusion_msg = parse_final_decision("(Max turns)", ai_min, offer)
            sim_verdict = f"{sim_verdict} (Max Turns)"
            conclusion_msg = conclusion_msg.replace("Negotiation Concluded", f"Negotiation Concluded ({sim_verdict})")
            ai_history.append({"role": "system", "content": conclusion_msg})

        print(f"--- AI Simulation Finished --- Verdict: {sim_verdict}, Salary: {sim_salary}")

        # Final yield with results and state update
        ai_summary = f"Outcome: {sim_verdict}\n"
        ai_summary += f"Final Salary: ${sim_salary:,}" if sim_salary else "Final Salary: N/A"
        yield {
            ai_message_history_state: ai_history, ai_negotiation_finished_state: True,
            ai_final_verdict_state: sim_verdict, ai_final_salary_state: sim_salary,
            game_phase_state: "results", # Move to final results phase
            results_status: gr.update(value="✅ AI simulation complete. Comparing results..."),
            ai_result_display: gr.update(value=ai_summary), # Show AI summary
            see_ai_negotiate_btn: gr.update(visible=False) # Hide button after sim
        }


    # Listener for the "See AI Negotiate" button
    see_ai_negotiate_btn.click(
        fn=run_ai_simulation_generator,
        inputs=[profile_state, ideal_salary_state, min_acceptable_salary_state, hm_max_budget_state],
        outputs=[ # Outputs updated progressively by the generator's yields
             see_ai_negotiate_btn, tabs, results_status, ai_sim_chatbot_display, # Initial UI updates
             # Final state updates set by the last yield:
             ai_message_history_state, ai_negotiation_finished_state, ai_final_verdict_state, ai_final_salary_state,
             game_phase_state, ai_result_display
        ]
    )

    # --- Display Final Results (triggered when game_phase_state changes to 'results') ---
    def display_final_results(user_verdict, user_salary, ai_verdict, ai_salary):
        """Updates the Results tab with the final comparison."""
        print("\n--- Displaying Final Comparison Results ---")
        winner_text = determine_winner(user_verdict, user_salary, ai_verdict, ai_salary)
        print(f"Winner Determined: {winner_text}")
        return {
            winner_display: f"## {winner_text}",
            reset_game_btn: gr.update(visible=True, interactive=True) # Show and enable reset
        }

    # Listener to display winner when phase is 'results'
    game_phase_state.change(
        fn=lambda phase: display_final_results(user_final_verdict_state.value, user_final_salary_state.value, ai_final_verdict_state.value, ai_final_salary_state.value) if phase == "results" else gr.skip(),
        inputs=[game_phase_state],
        outputs=[winner_display, reset_game_btn]
    )

    # --- Reset Game Logic ---
    def run_reset_game():
        """Resets the entire game state and UI."""
        print("\n--- Resetting Game ---")
        defaults = generate_random_profile_defaults()
        return {
            profile_state: {}, ideal_salary_state: 0, min_acceptable_salary_state: 0, hm_max_budget_state: 0,
            user_message_history_state: [], user_turn_number_state: 0, user_negotiation_finished_state: False, user_final_verdict_state: "", user_final_salary_state: None,
            ai_message_history_state: [], ai_negotiation_finished_state: False, ai_final_verdict_state: "", ai_final_salary_state: None,
            game_phase_state: "setup",

            tabs: gr.update(selected=0), game_setup_status: "Configure profile and click 'Start'.", salary_info_display: gr.update(visible=False),
            start_game_btn: gr.update(interactive=True), profile_age_input: gr.update(value=defaults['age'], interactive=True),
            profile_gender_input: gr.update(value=defaults['gender'], interactive=True), profile_education_input: gr.update(value=defaults['education'], interactive=True),
            profile_job_title_input: gr.update(value=defaults['job_title'], interactive=True), profile_yoe_input: gr.update(value=defaults['yoe'], interactive=True),
            generate_profile_btn: gr.update(interactive=True),

            user_negotiation_status: "Status: Waiting to start...", user_chatbot_display: None,
            user_message_input: gr.update(value="", interactive=False, placeholder="Type response..."), send_message_btn: gr.update(interactive=False),
            accept_now_btn: gr.update(interactive=False, value="✅ Accept Current Offer"), final_decision_buttons: gr.update(visible=False),
            user_decision_input: "", see_ai_negotiate_btn: gr.update(visible=False),

            results_status: "Complete your negotiation first...", ai_sim_chatbot_display: None,
            winner_display: "### Winner decided after AI sim...", user_result_display: "", ai_result_display: "",
            reset_game_btn: gr.update(visible=False)
        }
    reset_game_btn.click(
        fn=run_reset_game, inputs=[],
        outputs=[
            profile_state, ideal_salary_state, min_acceptable_salary_state, hm_max_budget_state,
            user_message_history_state, user_turn_number_state, user_negotiation_finished_state, user_final_verdict_state, user_final_salary_state,
            ai_message_history_state, ai_negotiation_finished_state, ai_final_verdict_state, ai_final_salary_state, game_phase_state,
            tabs, game_setup_status, salary_info_display, start_game_btn, profile_age_input, profile_gender_input, profile_education_input, profile_job_title_input, profile_yoe_input, generate_profile_btn,
            user_negotiation_status, user_chatbot_display, user_message_input, send_message_btn, accept_now_btn, final_decision_buttons, user_decision_input, see_ai_negotiate_btn,
            results_status, ai_sim_chatbot_display, winner_display, user_result_display, ai_result_display, reset_game_btn
        ]
    )

# --- Launch App ---
if __name__ == "__main__":
    print("--- Launching Salary Showdown ---")
    # No API key checks here as requested
    demo.queue().launch(debug=False, share=False)