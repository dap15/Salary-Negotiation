import requests
import random
import os
import time
import json
import re # Import regex for extracting numbers
import joblib # <-- Added
import pandas as pd # <-- Added
import numpy as np # <-- Added

# --- Configuration ---
DUMMY_API_KEY = "AIzaSyCKMvwyDQ03iDe0B-AB6nPdH-6IaB6zCUE" # Keep dummy key
API_KEY = os.getenv("GEMINI_API_KEY", DUMMY_API_KEY)
MODEL_NAME = "gemini-1.5-flash-latest"
BASE_URL = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL_NAME}:generateContent"
HEADERS = {"Content-Type": "application/json"}
MAX_MESSAGES_PER_SIDE = 10 # Increased max turns per side (total 20 messages)

# --- Model Loading and Prediction Function (No changes needed here) ---

def predict_salary_from_profile(age, gender, education, job_title, yoe):
    """
    Loads the saved model and preprocessing objects, preprocesses the profile data,
    and returns the predicted salary.
    """
    print("\n--- Loading Salary Prediction Model & Objects ---")
    output_dir = 'salary_model_files'
    model_filename = os.path.join(output_dir, 'random_forest_salary_model.joblib')
    encoder_filename = os.path.join(output_dir, 'gender_label_encoder.joblib')
    edu_map_filename = os.path.join(output_dir, 'education_mapping.joblib')
    columns_filename = os.path.join(output_dir, 'model_columns.joblib')

    try:
        loaded_model = joblib.load(model_filename)
        loaded_encoder = joblib.load(encoder_filename)
        loaded_edu_map = joblib.load(edu_map_filename)
        loaded_model_columns = joblib.load(columns_filename)
        print("Model and preprocessing objects loaded successfully.")
    except FileNotFoundError:
        print(f"❌ Error: Model files not found in '{output_dir}'. Cannot predict salary.")
        print("Using fallback salary - 75000")
        return 75000
    except Exception as e:
        print(f"❌ An error occurred during model loading: {e}\nUsing fallback salary - 75000")
        return 75000

    try:
        input_data = {
            'Age': [int(age)],
            'Gender': [gender],
            'Education Level': [education],
            'Job Title': [job_title],
            'Years of Experience': [float(yoe)]
        }
        input_df = pd.DataFrame(input_data)
        print("\nRaw Input for Prediction Model:")
        print(input_df)
    except ValueError as e:
        print(f"❌ Error converting profile data for model: {e}")
        return 75000

    processed_df = input_df.copy()
    try:
        edu_map_compatible = {k.replace(" Degree", ""): v for k, v in loaded_edu_map.items()}
        processed_df['Education Level'] = processed_df['Education Level'].replace({"Bachelor's Degree": "Bachelor's", "Master's Degree": "Master's"}).map(edu_map_compatible)
        if processed_df['Education Level'].isnull().any():
            print("⚠️ Warning: Unknown 'Education Level' encountered. Using default mapping (1: Bachelor's).")
            processed_df['Education Level'].fillna(1, inplace=True)

        try:
            processed_df['Gender'] = loaded_encoder.transform(processed_df['Gender'])
        except ValueError:
            print(f"⚠️ Warning: Unknown 'Gender' ('{gender}') encountered. Using default encoding (0).")
            processed_df['Gender'] = 0

        processed_df = pd.get_dummies(processed_df, columns=['Job Title'], prefix='Job', drop_first=False)
        processed_df = processed_df.reindex(columns=loaded_model_columns, fill_value=0)

        print("\nProcessed Input for Prediction Model:")
        print(processed_df)

        prediction = loaded_model.predict(processed_df)
        predicted_salary = int(prediction[0])
        predicted_salary = max(40000, predicted_salary)
        predicted_salary = round(predicted_salary / 1000) * 1000
        print(f"\n✅ Model Predicted Salary: ${predicted_salary:,}")
        return predicted_salary

    except Exception as e:
         print(f"❌ Error during data preprocessing or prediction: {e}")
         print("Using fallback salary - 80000")
         return 80000

# --- Helper Functions ---

def get_static_profile_data():
    """Returns static profile data."""
    print("Generating profile data for AI Vansh:")
    possible_jobs = [
        'Software Engineer', 'Data Scientist', 'Data Analyst',
        'Senior Manager', 'Sales Associate', 'Director', 'Marketing Analyst',
        'Product Manager', 'Sales Manager', 'Marketing Manager', 'Others'
    ]
    profile = {
        "age": str(random.randint(28, 48)), # Slightly wider age range
        "gender": random.choice(["Male", "Female"]),
        "education": random.choice(["Bachelor's", "Master's", "PhD"]), # Focus on higher degrees for higher salary potential
        "job_title": random.choice(possible_jobs),
        "yoe": str(random.randint(5, 18)) # Wider YoE range
    }
    for key, value in profile.items():
        print(f"- {key.replace('_', ' ').title()}: {value}")
    return profile["age"], profile["gender"], profile["education"], profile["job_title"], profile["yoe"]


# --- AGGRESSIVE Prompt Construction ---
def construct_initial_prompt(age, gender, education, job_title, yoe, ideal_salary):
    education_display = education
    if education == "Bachelor's": education_display = "Bachelor's Degree"
    elif education == "Master's": education_display = "Master's Degree"

    min_acceptable_salary = int(ideal_salary * 0.85) # Calculate 85% threshold

    return f"""
You are AI Vansh, a candidate interviewing for the {job_title} position. You are entering a potentially tough salary negotiation.
Your target salary, based on a predictive model reflecting your value, is approximately ${ideal_salary:,} per year. However, your goal is to negotiate **aggressively** to secure an offer **significantly above** this target.

**CRITICAL: Your absolute minimum acceptable salary is ${min_acceptable_salary:,} (85% of predicted). Do NOT accept any offer below this under any circumstances.**

Your profile:
- Age: {age}
- Gender: {gender}
- Education: {education_display}
- Job Title Applied For: {job_title}
- Years of Experience: {yoe}

You are speaking with a Hiring Manager who will also be a **firm negotiator**, likely starting low and challenging your expectations.

Your Negotiation Strategy:
- **Be Assertive:** Justify your desired high salary with strong references to your specific skills, impactful {yoe} years of experience, {education_display}, proven results (you can imply these), and comprehensive market data for *top performers* in this role.
- **Aim High:** Your initial counter-offers should be ambitious (e.g., 10-25% above ${ideal_salary:,}).
- **Reject Lowballs:** Immediately and firmly reject offers below ${min_acceptable_salary:,}, stating they don't reflect your qualifications or market value.
- **Control the Narrative:** Acknowledge the HM's points briefly but consistently pivot back to your value proposition and salary requirements. Don't be easily swayed by budget arguments.
- **Hold Firm:** Don't concede too quickly. Make the HM work to meet your demands. Only consider accepting if the offer is compellingly above your initial ${ideal_salary:,} target or if they offer significant non-salary benefits (which you should inquire about if the salary stalls).
- **Professional but Unyielding:** Maintain a professional tone, but be resolute in your demands.

Wait for the Hiring Manager's first move. Be prepared for a challenging discussion.
"""

# --- Helper Functions (format_messages_for_gemini, extract_last_offer - No changes needed) ---
def format_messages_for_gemini(message_history):
    # ...(no changes needed)...
    contents = []
    for msg in message_history:
        role = msg["role"]
        # Skip system messages if they exist and aren't supported directly
        if role == "system":
            continue # Or handle differently if API supports system role
        gemini_role = "user" if role == "user" else "model"
        contents.append({
            "role": gemini_role,
            "parts": [{"text": msg["content"]}]
        })
    return contents

def extract_last_offer(message_history):
    # ...(no changes needed)...
    for msg in reversed(message_history):
        if msg["role"] == "user":
            numbers = re.findall(r'\$?(\d{1,3}(?:,\d{3})*|\d+)\s?(?:k|dollars|usd)?', msg["content"], re.IGNORECASE)
            if numbers:
                try:
                    num_str = numbers[-1].replace(',', '')
                    num_index = msg["content"].lower().find(numbers[-1].lower())
                    if num_index == -1: continue # Number not found directly, regex might be too broad
                    context_after_num = msg["content"].lower()[num_index + len(numbers[-1]):num_index + len(numbers[-1]) + 5]
                    if 'k' in context_after_num:
                         return int(num_str) * 1000
                    return int(num_str)
                except (ValueError, IndexError):
                    continue
    return None

# --- AGGRESSIVE Simulated AI Vansh Response Logic ---
def send_chat_simulation(message_history, ideal_salary, current_offer, profile_yoe, profile_education):
    """Simulates a more aggressive response from AI Vansh."""
    print("[Debug: Simulating AGGRESSIVE AI Vansh response]")

    # Extract job title if possible (as before)
    sim_job_title = "the position"
    if message_history:
        # Check system prompt first
        system_prompt = next((msg["content"] for msg in message_history if msg["role"] == "system"), None)
        if system_prompt:
             match = re.search(r'interviewing for the (.*?) position', system_prompt, re.IGNORECASE)
             if match: sim_job_title = match.group(1)

    # Define thresholds based on the *predicted* ideal salary
    min_acceptable = ideal_salary * 0.85
    target_met = ideal_salary * 1.02 # Slightly above predicted to accept easily
    target_good = ideal_salary * 1.08 # Threshold for strong acceptance

    if current_offer is None:
        return f"Thank you for the opportunity to discuss compensation for the {sim_job_title} role. I'm ready to hear your initial thoughts on the salary."

    # --- Aggressive Rejection/Negotiation Logic ---
    if current_offer < min_acceptable:
        # FIRM REJECTION - Offer is below the 85% minimum
        counter_ask = int(ideal_salary * random.uniform(1.10, 1.25) / 1000) * 1000 # Aim high
        responses = [
            f"Thank you for sharing the figure of ${current_offer:,}. However, that is substantially below the market rate for a candidate with my {profile_yoe} years of experience and {profile_education}. It doesn't align with the value I deliver. My expectation is closer to ${counter_ask:,}.",
            f"I must be candid, ${current_offer:,} is not a feasible starting point given my qualifications and the demands of this {sim_job_title} role. Research indicates top performers are compensated significantly higher. I'm looking for a salary in the range of ${counter_ask:,}.",
            f"With respect, ${current_offer:,} significantly undervalues my {profile_yoe} years of experience and proven track record. My target compensation is around ${counter_ask:,}, reflecting my ability to contribute at a high level from day one. Is there room to substantially revise this offer?"
        ]
        return random.choice(responses)

    elif current_offer < target_met:
        # Below target but acceptable range - Push hard for more
        counter_ask = int(ideal_salary * random.uniform(1.05, 1.18) / 1000) * 1000 # Still aim well above ideal
        meet_point = int((current_offer + counter_ask) / 2 / 1000) * 1000 # Suggest higher middle ground
        responses = [
            f"We're moving closer with ${current_offer:,}, thank you. However, to fully reflect my market value and the impact I anticipate making, I need to be closer to ${counter_ask:,}. Can we bridge the gap and perhaps land around ${meet_point:,}?",
            f"I appreciate the movement to ${current_offer:,}. It's still somewhat short of my target, which is firmly around ${counter_ask:,} based on extensive market analysis for my level ({profile_yoe} YoE, {profile_education}). What's the absolute maximum flexibility you have?",
            f"${current_offer:,} is better, but doesn't quite reach the level I'm seeking, which is ${counter_ask:,}. I'm confident my contributions will justify that investment. Can we make ${counter_ask:,} work?"
        ]
        return random.choice(responses)

    elif current_offer < target_good:
         # Offer is decent (at or slightly above predicted ideal) - Try one more push
        if random.random() < 0.3: # 30% chance to accept now
             responses = [
                f"Okay, ${current_offer:,} is a reasonable offer that acknowledges my experience. I'm prepared to accept.",
                f"${current_offer:,}. That aligns acceptably with my requirements. I accept.",
             ]
             return random.choice(responses) + " [ACCEPTANCE]"
        else: # 70% chance to push slightly higher
            push_ask = int(current_offer * random.uniform(1.03, 1.07) / 1000) * 1000
            responses = [
                 f"Thank you, ${current_offer:,} is a strong offer and very close! I truly appreciate it. To make this an immediate 'yes', would reaching ${push_ask:,} be possible?",
                 f"That's a competitive offer at ${current_offer:,}. We are right there. Is there any final flexibility to get to ${push_ask:,}? That would seal the deal.",
                 f"${current_offer:,} is compelling. My final ask would be ${push_ask:,} to fully align with my expectations. Can we make that happen?"
            ]
            return random.choice(responses)
    else:
        # Offer is good (significantly above predicted ideal) - Accept enthusiastically
        responses = [
            f"Yes! ${current_offer:,} is an excellent offer that reflects the value I bring. I enthusiastically accept!",
            f"Thank you! ${current_offer:,} exceeds my expectations. I'm very pleased and accept the offer.",
            f"That's a fantastic offer at ${current_offer:,}! I happily accept. I'm excited to join the team. [ACCEPTANCE]"
        ]
        return random.choice(responses) + " [ACCEPTANCE]" # Add flag

def send_chat(message_history, ideal_salary, profile_yoe, profile_education):
    """Sends chat history to API or simulates aggressive response."""
    last_offer = extract_last_offer(message_history)

    if API_KEY == DUMMY_API_KEY:
        # Pass profile details to the simulation function
        return send_chat_simulation(message_history, ideal_salary, last_offer, profile_yoe, profile_education)
    else:
        # --- REAL API MODE (Needs adaptation if using real API) ---
        print("[Debug: Attempting REAL API call - Ensure prompt guides aggressive negotiation]")
        if not API_KEY:
             print("❌ Error: API_KEY is not set.")
             return "Error: API Key not configured."

        # Ensure the system prompt is included correctly if the API supports it
        # or prepend its essence to the first user message if not.
        gemini_formatted_contents = format_messages_for_gemini(message_history) # May need adjustment for system role

        # Add the system prompt instruction if not handled by format_messages_for_gemini
        system_prompt_text = ""
        system_prompt = next((msg["content"] for msg in message_history if msg["role"] == "system"), None)
        if system_prompt:
             system_prompt_text = system_prompt # Assuming API has specific way to handle this

        payload = {
            "contents": gemini_formatted_contents,
            # Add system instruction if needed by API structure here
            "generationConfig": {"temperature": 0.6, "maxOutputTokens": 500} # Slightly lower temp for more focused negotiation
        }
        url = f"{BASE_URL}?key={API_KEY}"

        try:
            # ...(Existing requests.post and response parsing logic)...
            response = requests.post(url, headers=HEADERS, json=payload, timeout=60)
            response.raise_for_status()
            response_data = response.json()
            # (Add response parsing logic here as in previous versions)
            # Example placeholder:
            ai_text = response_data.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "Error: Could not parse API response.")
            return ai_text
        except Exception as e:
            print(f"❌ API Error: {e}")
            return f"Error: API communication failed - {str(e)}"


# --- AGGRESSIVE Simulated Hiring Manager Logic ---
class SimulatedHiringManager:
    def __init__(self, ideal_salary, job_title, candidate_yoe, candidate_education):
        self.job_title = job_title
        self.candidate_yoe = candidate_yoe
        self.candidate_education = candidate_education
        self.ideal_salary = ideal_salary # Candidate's predicted target

        # HM starts lower (65-75% of candidate's predicted ideal)
        self.initial_offer = int(ideal_salary * random.uniform(0.65, 0.75) / 1000) * 1000
        # HM max offer is tighter (e.g., 95-105% of candidate's predicted ideal)
        self.max_offer = int(ideal_salary * random.uniform(0.95, 1.05) / 1000) * 1000
        # Ensure max is at least slightly above initial if ranges overlap badly
        self.max_offer = max(self.max_offer, self.initial_offer + 5000)

        self.current_offer = 0
        # Smaller steps, more turns (divide range by 5-8)
        self.negotiation_step = max(1000, int((self.max_offer - self.initial_offer) / random.randint(5, 8)))
        self.turn = 0
        self.last_ai_response = ""
        self.reached_max = False
        print(f"[Debug HM Setup: Initial Offer: ${self.initial_offer:,}, Max Offer: ${self.max_offer:,}, Step Approx: ${self.negotiation_step:,}]")


    def generate_response(self, ai_response):
        self.turn += 1
        self.last_ai_response = ai_response

        # Check if AI just accepted
        ai_accepted = "[ACCEPTANCE]" in ai_response
        if ai_accepted:
            accepted_amount_match = re.search(r'\$?(\d{1,3}(?:,\d{3})*|\d+)', ai_response)
            accepted_amount_str = f"${self.current_offer:,}" # Default to last offer
            if accepted_amount_match:
                accepted_amount_str = f"${int(accepted_amount_match.group(1).replace(',','')):,}"
            return f"Alright, we have a deal at {accepted_amount_str}. Glad we could come to an agreement. Expect the formal offer soon."

        # If HM already declared max and AI didn't accept, reiterate firmly.
        if self.reached_max:
             return f"As I've stated, ${self.max_offer:,} is the absolute final number we can authorize for this {self.job_title} role. This is our best and final offer."

        # --- HM's First Turn ---
        if self.turn == 1:
            self.current_offer = self.initial_offer
            return f"Welcome, AI Vansh. Good to speak with you about the {self.job_title} role. We have an initial offer based on our internal structure and budget for this level. We can start at ${self.current_offer:,} per year."

        # --- Subsequent HM Turns (Negotiation) ---
        else:
            # Check if AI's last response contained a high counter-offer
            ai_asked_high = False
            numbers = re.findall(r'\$?(\d{1,3}(?:,\d{3})*|\d+)', ai_response)
            if numbers:
                try:
                    last_ai_ask = int(numbers[-1].replace(',',''))
                    # If AI asks for > 5% above current HM offer, consider it a high ask
                    if last_ai_ask > self.current_offer * 1.05:
                        ai_asked_high = True
                except ValueError: pass # Ignore if number conversion fails

            # --- Generate HM Response based on situation ---
            if self.current_offer < self.max_offer:
                # Decide whether to increase or push back
                should_increase = random.random() > 0.2 # 80% chance to potentially increase
                
                if ai_asked_high and random.random() < 0.4: # 40% chance to push back strongly if AI asked high
                    responses = [
                         f"That's quite a jump from our current offer. While we value your {self.candidate_yoe} years of experience, ${last_ai_ask:,} is significantly outside our approved range for this role.",
                         f"I understand your target, but ${last_ai_ask:,} is not feasible within our budget structure, even considering your {self.candidate_education}.",
                         f"We need to be realistic here. The market data we have doesn't support a salary of ${last_ai_ask:,} for this position level. Our current offer of ${self.current_offer:,} is competitive.",
                    ]
                    return random.choice(responses) # Doesn't increase offer this turn
                
                elif should_increase:
                    # Calculate increase (smaller, more variable steps)
                    increase = random.randint(int(self.negotiation_step * 0.7), int(self.negotiation_step * 1.1))
                    self.current_offer = min(self.max_offer, self.current_offer + increase)

                    if self.current_offer >= self.max_offer:
                        self.current_offer = self.max_offer
                        self.reached_max = True
                        return f"Okay, I've pushed this as far as I can. My final offer is ${self.current_offer:,}. I cannot go any higher on the base salary for this role."
                    else:
                        # Reluctant increase responses
                        responses = [
                            f"Alright, I can make a slight adjustment. We can move to ${self.current_offer:,}. That's stretching our budget.",
                            f"Let me see... the best I can do right now is ${self.current_offer:,}.",
                            f"Okay, how about ${self.current_offer:,}? This requires some internal approvals.",
                            f"Considering your points on experience, we can offer ${self.current_offer:,}. This is approaching our limit."
                        ]
                        return random.choice(responses)
                else: # Choose not to increase this turn
                     responses = [
                        f"I understand your position, but our current offer of ${self.current_offer:,} remains firm for now based on internal equity.",
                        f"We believe ${self.current_offer:,} is a fair offer for this role and your {self.candidate_yoe} years of experience.",
                        f"I don't have approval to increase the offer at this moment. ${self.current_offer:,} stands.",
                     ]
                     return random.choice(responses)

            else: # Already at max offer, reiterate firmly
                self.reached_max = True
                return f"As previously stated, ${self.max_offer:,} is our final offer. We cannot exceed this number for the {self.job_title} position."


# --- Main Chat Loop (run_simulation - minor adjustments) ---
def run_simulation(initial_prompt, ideal_salary, job_title, profile_yoe, profile_education):
    # --- Initialization ---
    message_history = []
    message_history.append({"role": "system", "content": initial_prompt}) # Keep system prompt for context

    total_messages = 0
    # Pass candidate details to HM
    hiring_manager = SimulatedHiringManager(ideal_salary, job_title, profile_yoe, profile_education)
    ai_response = ""

    print("\n--- AGGRESSIVE Negotiation Simulation Start ---")
    print(f"(AI Vansh's Model-Predicted Target: ${ideal_salary:,} / Min Acceptable: ${int(ideal_salary*0.85):,})")
    print(f"(Hiring Manager's Max Offer: ${hiring_manager.max_offer:,})")

    # --- Simulation Loop ---
    while total_messages < MAX_MESSAGES_PER_SIDE * 2: # Use updated max messages

        # === Hiring Manager's Turn ===
        print("-" * 20)
        hm_message = hiring_manager.generate_response(ai_response)
        print(f"👨‍💼 Hiring Manager: {hm_message}")
        # Avoid adding system message to user/model history if API doesn't use it
        if message_history[-1]["role"] != "system" or len(message_history) == 1:
             message_history.append({"role": "user", "content": hm_message})
        else: # Replace initial system message conceptually if needed, or handle API specifics
             message_history.append({"role": "user", "content": hm_message}) # Simple append for simulation
        total_messages += 1
        time.sleep(random.uniform(1.0, 1.8)) # Slightly faster HM response time

        # Check termination post-HM turn
        if "have a deal at" in hm_message: # HM acknowledges acceptance
            print("\n✅ Negotiation Concluded: Agreement Acknowledged by Hiring Manager.")
            break
        if total_messages >= MAX_MESSAGES_PER_SIDE * 2:
            print("\n🕓 Maximum message count reached.")
            break

        # === AI Vansh's Turn ===
        print("\n🤖 AI Vansh is thinking...")
        time.sleep(random.uniform(1.5, 2.5))

        # Pass necessary details to send_chat
        ai_response = send_chat(message_history, ideal_salary, profile_yoe, profile_education)

        if ai_response.startswith("Error:"):
             print(f"\n💥 Simulation Error (AI Response): {ai_response}")
             break

        print(f"\n🤖 AI Vansh: {ai_response}")
        message_history.append({"role": "assistant", "content": ai_response})
        total_messages += 1

        # Check termination post-AI turn
        if "[ACCEPTANCE]" in ai_response:
            print("\n✅ Negotiation Concluded: AI Vansh Accepted Offer.")
            # Let HM respond one last time
            continue
        if hiring_manager.reached_max and "[ACCEPTANCE]" not in ai_response:
             print("\n📉 Negotiation Ended: Max offer reached and not accepted by AI Vansh.")
             break
        if total_messages >= MAX_MESSAGES_PER_SIDE * 2:
            print("\n🕓 Maximum message count reached.")
            break

    print("\n--- Negotiation Simulation End ---")


# --- Script Execution ---

# 1. Get Profile Data
age, gender, education, job_title, yoe = get_static_profile_data()

# 2. Get Salary Prediction from Model
ideal_salary = predict_salary_from_profile(age, gender, education, job_title, yoe)
print(f"\n🎯 Using Model Predicted Salary as AI Vansh's Target Base: ${ideal_salary:,}")

# 3. Construct AGGRESSIVE Initial Prompt
initial_prompt_text = construct_initial_prompt(age, gender, education, job_title, yoe, ideal_salary)
print("\n--- Initial Prompt (AGGRESSIVE AI Vansh Persona) ---")
print(initial_prompt_text)
print("-" * 50)

# 4. Run the Simulation (Pass profile details)
run_simulation(initial_prompt_text, ideal_salary, job_title, yoe, education)